import sys
import socket
from collections import deque

HOST = '127.0.0.1'
PORT = 8747
ARGS = sys.argv[1] if len(sys.argv) > 1 else ''
sock = socket.socket()

def init(nickname):
    try:
        print(f'[STATUS] Trying to connect to {HOST}:{PORT}...')
        sock.connect((HOST, PORT))
        print('[STATUS] Connected')
        return submit(f'INIT {nickname}')
    except Exception as e:
        print('[ERROR] Failed to connect.')
        print(e)

def submit(string_to_send):
    try:
        send_data = ARGS + string_to_send + ' '
        sock.send(send_data.encode('utf-8'))
        return receive()
    except Exception:
        print('[ERROR] Failed to send data.')
    return None

def receive():
    try:
        game_data = (sock.recv(4096)).decode()
        if game_data and game_data[0].isdigit() and int(game_data[0]) > 0:
            return game_data
        print('[STATUS] No receive data from the main program.')
        close()
    except Exception:
        print('[ERROR] Failed to receive data.')

def close():
    try:
        if sock is not None:
            sock.close()
        print('[STATUS] Connection closed')
    except Exception:
        print('[ERROR] Connection corrupted.')

# state
map_data = [[]]
my_allies = {}
enemies = {}
codes = []

def parse_data(game_data):
    global map_data, my_allies, enemies, codes
    rows = game_data.split('\n')
    idx = 0
    header = rows[idx].split(' ')
    map_h = int(header[0]) if len(header) >= 1 else 0
    map_w = int(header[1]) if len(header) >= 2 else 0
    n_allies = int(header[2]) if len(header) >= 3 else 0
    n_enemies = int(header[3]) if len(header) >= 4 else 0
    n_codes = int(header[4]) if len(header) >= 5 else 0
    idx += 1

    map_data = [['' for _ in range(map_w)] for _ in range(map_h)]
    for i in range(map_h):
        cols = rows[idx + i].split(' ')
        for j in range(len(cols)):
            map_data[i][j] = cols[j]
    idx += map_h

    my_allies = {}
    for i in range(idx, idx + n_allies):
        parts = rows[i].split(' ')
        name = parts.pop(0) if parts else '-'
        my_allies[name] = parts
    idx += n_allies

    enemies = {}
    for i in range(idx, idx + n_enemies):
        parts = rows[i].split(' ')
        name = parts.pop(0) if parts else '-'
        enemies[name] = parts
    idx += n_enemies

    codes = []
    for i in range(idx, idx + n_codes):
        codes.append(rows[i])

    # assign back to module-level names
    globals()['map_data'] = map_data
    globals()['my_allies'] = my_allies
    globals()['enemies'] = enemies
    globals()['codes'] = codes

def find_positions(grid, goal):
    pos = []
    for r in range(len(grid)):
        for c in range(len(grid[0])):
            if grid[r][c] == goal:
                pos.append((r, c))
    return pos

def find_enemy_tanks(grid):
    """E로 시작하는 모든 적 탱크 위치 찾기 (E1, E2, E3 등)"""
    pos = []
    for r in range(len(grid)):
        for c in range(len(grid[0])):
            cell = grid[r][c]
            if cell and cell.startswith('E') and len(cell) > 1:  # E1, E2, E3 등
                pos.append((r, c))
    return pos

def bfs(grid, start, target, walls, destructable_wall, avoid_supplies=False):
    rows, cols = len(grid), len(grid[0])
    q = deque([(start, [])])
    visited = {start}
    
    # 시작 위치에서 사거리 3 이내의 타겟이 있는지 확인 (직선만)
    # 단, 보급품은 쏘지 않음 - 오직 적 탱크(E1,E2,E3)나 포탑(X)만 공격
    sr, sc = start
    tr, tc = target
    target_cell = grid[tr][tc] if 0 <= tr < rows and 0 <= tc < cols else None
    
    # 보급품은 쏘지 않음
    if target_cell == 'F':
        print(f"[DEBUG] Target is supply (F), won't fire at it")
    elif target_cell == 'X' or (target_cell and target_cell.startswith('E')):  # 포탑이나 적 탱크(E1,E2,E3)만 공격
        for d, (dr, dc) in enumerate(DIRS):
            for distance in range(1, 4):  # 사거리 1~3
                nr, nc = sr + dr * distance, sc + dc * distance
                if (nr, nc) == target:
                    # 사이에 장애물이 있는지 확인
                    clear_path = True
                    for check_dist in range(1, distance):
                        check_r, check_c = sr + dr * check_dist, sc + dc * check_dist
                        if 0 <= check_r < rows and 0 <= check_c < cols:
                            cell = grid[check_r][check_c]
                            if cell in walls or cell == destructable_wall or (avoid_supplies and cell == 'F'):
                                clear_path = False
                                break
                        else:
                            clear_path = False
                            break
                    
                    if clear_path:
                        print(f"[DEBUG] Found target {target_cell} at {target} within range {distance}, firing!")
                        return [FIRE_CMDS[d]], 1
    
    while q:
        (r, c), actions = q.popleft()
        if (r, c) == target:
            return actions, len(actions)
        for d, (dr, dc) in enumerate(DIRS):
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols:
                cell = grid[nr][nc]
                if cell in walls:
                    continue
                # 메가 2개 이상일 때 보급소 피하기
                if avoid_supplies and cell == 'F':
                    continue
                if cell == destructable_wall:
                    if (nr, nc) == target:
                        return actions + [FIRE_CMDS[d]], len(actions) + 1
                    continue
                if (nr, nc) not in visited:
                    visited.add((nr, nc))
                    q.append(((nr, nc), actions + [MOVE_CMDS[d]]))
    # 주변 나무 부수기 시도 (한 칸)
    for d, (dr, dc) in enumerate(DIRS):
        nr, nc = start[0] + dr, start[1] + dc
        if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] == destructable_wall:
            return [FIRE_CMDS[d]], 1
    return [], float('inf')

def decode_code(code):
    result = []
    for ch in code:
        if 'A' <= ch <= 'Z':
            result.append(chr((ord(ch) - ord('A') + 9) % 26 + ord('A')))
        else:
            result.append(ch)
    return ''.join(result)

def is_adjacent_to_F(pos, supplies):
    if not supplies:
        return False
    r, c = pos
    for sr, sc in supplies:
        if abs(sr - r) + abs(sc - c) == 1:
            return True
    return False

def pick_best_in_group(start, targets, avoid_supplies=False):
    best_actions, best_sym, best_len = [], None, float('inf')
    for t in targets:
        actions, plen = bfs(map_data, start, t, WALL_SYMBOL, DESTRUCTABLE_SYMBOL, avoid_supplies)
        if plen < best_len:
            best_actions, best_len = actions, plen
            try:
                best_sym = map_data[t[0]][t[1]]
            except Exception:
                best_sym = None
    return best_actions, best_sym, best_len

def fallback_step_toward(start, targets, avoid_supplies=False):
    if not targets:
        return None
    sr, sc = start
    tgt = min(targets, key=lambda p: abs(p[0]-sr)+abs(p[1]-sc))
    tr, tc = tgt
    cur_d = abs(tr - sr) + abs(tc - sc)
    rows, cols = len(map_data), len(map_data[0])
    candidates = []
    for d, (dr, dc) in enumerate(DIRS):
        nr, nc = sr + dr, sc + dc
        if 0 <= nr < rows and 0 <= nc < cols:
            cell = map_data[nr][nc]
            if cell not in WALL_SYMBOL and cell != DESTRUCTABLE_SYMBOL:
                # 메가 2개 이상일 때 보급소 피하기
                if avoid_supplies and cell == 'F':
                    continue
                new_d = abs(tr - nr) + abs(tc - nc)
                candidates.append((new_d, d))
    # 거리 줄이는 방향 있으면 그쪽으로
    for new_d, d in sorted(candidates):
        if new_d < cur_d:
            return MOVE_CMDS[d]
    # 아니면 그냥 첫 번째 이동 가능한 방향으로라도
    if candidates:
        return MOVE_CMDS[candidates[0][1]]
    # 이동 가능한 게 전혀 없으면 대기
    return 'A'


# constants
DIRS = [(0,1),(1,0),(0,-1),(-1,0)]
MOVE_CMDS = {0: "R A", 1: "D A", 2: "L A", 3: "U A"}
FIRE_CMDS = {0: "R F", 1: "D F", 2: "L F", 3: "U F"}
WALL_SYMBOL = {'R','W'}
DESTRUCTABLE_SYMBOL = 'T'

# init
NICKNAME = '대전4_한가희'
game_data = init(NICKNAME)
if game_data:
    parse_data(game_data)

# main loop
while game_data is not None:
    start_pos = find_positions(map_data, 'M')
    if not start_pos:
        break
    start = start_pos[0]

    supplies = find_positions(map_data, 'F')
    enemies_tank = find_enemy_tanks(map_data)  # E1, E2, E3 등 모든 적 탱크 찾기
    fortress = find_positions(map_data, 'X')

    # read mega count safely and cap at 10
    mega_count = 0
    if 'M' in my_allies:
        try:
            mega_count = int(my_allies['M'][3])
        except Exception:
            mega_count = 0
    if mega_count > 10:
        mega_count = 10
        my_allies['M'][3] = '10'

    # DEBUG: 상태 출력
    print(f"[DEBUG] mega={mega_count} start={start} supplies={len(supplies)} E={len(enemies_tank)} X={len(fortress)}")
    print(f"[DEBUG] Map dimensions: {len(map_data)}x{len(map_data[0]) if map_data else 0}")
    
    # DEBUG: 맵 전체 출력해서 실제 적 탱크 위치 확인
    print("[DEBUG] Current map:")
    for i, row in enumerate(map_data):
        print(f"[DEBUG] Row {i}: {' '.join(row)}")
    
    # DEBUG: 각 심볼 위치 확인
    all_E = find_enemy_tanks(map_data)  # E1, E2, E3 등 적 탱크
    all_X = find_positions(map_data, 'X')
    all_F = find_positions(map_data, 'F')
    all_M = find_positions(map_data, 'M')
    print(f"[DEBUG] All enemy tank positions: {all_E}")
    print(f"[DEBUG] All X positions: {all_X}")
    print(f"[DEBUG] All F positions: {all_F}")
    print(f"[DEBUG] All M positions: {all_M}")
    print(f"[DEBUG] enemies dict: {enemies}")
    print(f"[DEBUG] my_allies dict: {my_allies}")

    # 메가가 0이고 보급소 인접하면 코드 디코딩
    if mega_count == 0 and is_adjacent_to_F(start, supplies) and codes:
        for c in codes:
            decoded = decode_code(c)
            msg = f"G {decoded}"
            print(f"[INFO] Decoding {c} -> {msg}")
            game_data = submit(msg)
            if game_data:
                parse_data(game_data)
        continue

    # 우선순위 결정 및 타겟 선택
    chosen_actions = []
    chosen_target_symbol = None
    
    if mega_count == 0:
        # 메가 0개: 보급소만 찾아감
        print("[DEBUG] Mega = 0, seeking supplies only")
        priority_groups = [supplies]
        for group in priority_groups:
            actions, sym, plen = pick_best_in_group(start, group, avoid_supplies=False)
            if actions:
                chosen_actions = actions
                chosen_target_symbol = sym
                print(f"[DEBUG] Selected target group with symbol {sym}, distance {plen}")
                break
    else:
        # 메가 1개 이상: 적 탱크 > 포탑 순서, 보급소 완전 무시
        print(f"[DEBUG] Mega = {mega_count}, FORCING combat priority, avoiding supplies")
        
        # 적 탱크가 있으면 무조건 적 탱크만 고려
        if enemies_tank:
            print(f"[DEBUG] Found {len(enemies_tank)} enemies_tank at {enemies_tank}")
            actions, sym, plen = pick_best_in_group(start, enemies_tank, avoid_supplies=True)
            if actions:
                chosen_actions = actions
                chosen_target_symbol = sym
                print(f"[DEBUG] FORCED selection: enemies_tank, symbol {sym}, distance {plen}")
            else:
                print("[DEBUG] No path to enemies_tank while avoiding supplies")
        
        # 적 탱크가 아예 없거나 경로가 없을 때만 포탑 고려
        if not chosen_actions:
            if not enemies_tank:
                print("[DEBUG] No enemies_tank found, trying fortress")
            else:
                print("[DEBUG] No path to enemies_tank found, trying fortress as fallback")
            
            if fortress:
                actions, sym, plen = pick_best_in_group(start, fortress, avoid_supplies=True)
                if actions:
                    chosen_actions = actions
                    chosen_target_symbol = sym
                    print(f"[DEBUG] Selected fortress as fallback, symbol {sym}, distance {plen}")
        
        if not chosen_actions:
            print("[DEBUG] No path to any target while avoiding supplies")

    # 출력 결정
    if chosen_actions:
        output = chosen_actions[0]
    else:
        # 대체: 가장 가까운 적/포탑으로 이동, 메가 1개 이상이면 보급소 피해서
        targets_for_fallback = enemies_tank if enemies_tank else fortress
        avoid_supplies_fallback = mega_count > 0
        output = fallback_step_toward(start, targets_for_fallback, avoid_supplies_fallback) or 'A'

    # 적이나 포탑을 공격하고 메가가 있으면 M 붙이고 메가 차감
    is_fire = any(output == v for v in FIRE_CMDS.values())
    is_enemy_or_fortress = (chosen_target_symbol == 'X' or 
                           (chosen_target_symbol and chosen_target_symbol.startswith('E')))
    
    if is_fire and is_enemy_or_fortress and mega_count > 0:
        output = output + ' M'
        try:
            cur = int(my_allies['M'][3])
            cur = max(0, cur - 1)
            my_allies['M'][3] = str(cur)
            mega_count = cur
        except Exception:
            mega_count = max(0, mega_count - 1)
        print(f"[DEBUG] Added MEGA to attack! Target: {chosen_target_symbol}, New mega count: {mega_count}")
    elif is_fire:
        print(f"[DEBUG] Fire command but no mega added. Target: {chosen_target_symbol}, Mega: {mega_count}")

    print(f"[DEBUG] chosen_target_symbol={chosen_target_symbol} -> sending: '{output}'")
    game_data = submit(output)
    if game_data:
        parse_data(game_data)

close()