import sys
import socket
from collections import deque

##############################
# 메인 프로그램 통신 변수 정의
##############################
HOST = '127.0.0.1'
PORT = 8747
ARGS = sys.argv[1] if len(sys.argv) > 1 else ''
sock = socket.socket()

##############################
# 메인 프로그램 통신 함수 정의
##############################

# 메인 프로그램 연결 및 초기화
def init(nickname):
    try:
        print(f'[STATUS] Trying to connect to {HOST}:{PORT}...')
        sock.connect((HOST, PORT))
        print('[STATUS] Connected')
        init_command = f'INIT {nickname}'

        return submit(init_command)

    except Exception as e:
        print('[ERROR] Failed to connect. Please check if the main program is waiting for connection.')
        print(e)

# 메인 프로그램으로 데이터(명령어) 전송
def submit(string_to_send):
    try:
        send_data = ARGS + string_to_send + ' '
        sock.send(send_data.encode('utf-8'))

        return receive()
        
    except Exception as e:
        print('[ERROR] Failed to send data. Please check if connection to the main program is valid.')

    return None

# 메인 프로그램으로부터 데이터 수신
def receive():
    try:
        game_data = (sock.recv(1024)).decode()

        if game_data and game_data[0].isdigit() and int(game_data[0]) > 0:
            return game_data

        print('[STATUS] No receive data from the main program.')    
        close()

    except Exception as e:
        print('[ERROR] Failed to receive data. Please check if connection to the main program is valid.')

# 연결 해제
def close():
    try:
        if sock is not None:
            sock.close()
        print('[STATUS] Connection closed')
    
    except Exception as e:
        print('[ERROR] Network connection has been corrupted.')

##############################
# 입력 데이터 변수 정의
##############################
map_data = [[]]  # 맵 정보. 예) map_data[0][1] - [0, 1]의 지형/지물
my_allies = {}  # 아군 정보. 예) my_allies['M'] - 플레이어 본인의 정보
enemies = {}  # 적군 정보. 예) enemies['X'] - 적 포탑의 정보
codes = []  # 주어진 암호문. 예) codes[0] - 첫 번째 암호문

##############################
# 입력 데이터 파싱
##############################

# 입력 데이터를 파싱하여 각각의 리스트/딕셔너리에 저장
def parse_data(game_data):
    # 입력 데이터를 행으로 나누기
    game_data_rows = game_data.split('\n')
    row_index = 0

    # 첫 번째 행 데이터 읽기
    header = game_data_rows[row_index].split(' ')
    map_height = int(header[0]) if len(header) >= 1 else 0 # 맵의 세로 크기
    map_width = int(header[1]) if len(header) >= 2 else 0  # 맵의 가로 크기
    num_of_allies = int(header[2]) if len(header) >= 3 else 0  # 아군의 수
    num_of_enemies = int(header[3]) if len(header) >= 4 else 0  # 적군의 수
    num_of_codes = int(header[4]) if len(header) >= 5 else 0  # 암호문의 수
    row_index += 1

    # 기존의 맵 정보를 초기화하고 다시 읽어오기
    map_data.clear()
    map_data.extend([[ '' for c in range(map_width)] for r in range(map_height)])
    for i in range(0, map_height):
        col = game_data_rows[row_index + i].split(' ')
        for j in range(0, len(col)):
            map_data[i][j] = col[j]
    row_index += map_height

    # 기존의 아군 정보를 초기화하고 다시 읽어오기
    my_allies.clear()
    for i in range(row_index, row_index + num_of_allies):
        ally = game_data_rows[i].split(' ')
        ally_name = ally.pop(0) if len(ally) >= 1 else '-'
        my_allies[ally_name] = ally
    row_index += num_of_allies

    # 기존의 적군 정보를 초기화하고 다시 읽어오기
    enemies.clear()
    for i in range(row_index, row_index + num_of_enemies):
        enemy = game_data_rows[i].split(' ')
        enemy_name = enemy.pop(0) if len(enemy) >= 1 else '-'
        enemies[enemy_name] = enemy
    row_index += num_of_enemies

    # 기존의 암호문 정보를 초기화하고 다시 읽어오기
    codes.clear()
    for i in range(row_index, row_index + num_of_codes):
        codes.append(game_data_rows[i])

# 파싱한 데이터를 화면에 출력
def print_data():
    print(f'\n----------입력 데이터----------\n{game_data}\n----------------------------')

    print(f'\n[맵 정보] ({len(map_data)} x {len(map_data[0])})')
    for i in range(len(map_data)):
        for j in range(len(map_data[i])):
            print(f'{map_data[i][j]} ', end='')
        print()

    print(f'\n[아군 정보] (아군 수: {len(my_allies)})')
    for k, v in my_allies.items():
        if k == 'M':
            print(f'M (내 탱크) - 체력: {v[0]}, 방향: {v[1]}, 보유한 일반 포탄: {v[2]}개, 보유한 메가 포탄: {v[3]}개')
        elif k == 'H':
            print(f'H (아군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (아군 탱크) - 체력: {v[0]}')

    print(f'\n[적군 정보] (적군 수: {len(enemies)})')
    for k, v in enemies.items():
        if k == 'X':
            print(f'X (적군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (적군 탱크) - 체력: {v[0]}')

    print(f'\n[암호문 정보] (암호문 수: {len(codes)})')
    for i in range(len(codes)):
        print(codes[i])

##############################
# 닉네임 설정 및 최초 연결
##############################
NICKNAME = 'megaboom'
game_data = init(NICKNAME)

###################################
# 알고리즘 함수/메서드 부분 구현 시작
###################################

# --- '포탑 돌격' 및 '1회성 보급' 전략을 위한 상수 및 함수 ---

DIRS = [(0,1), (1,0), (0,-1), (-1,0)]
MOVE_CMDS = {0: "R A", 1: "D A", 2: "L A", 3: "U A"}
FIRE_CMDS = {0: "R F", 1: "D F", 2: "L F", 3: "U F"}

START_SYMBOL = 'M'
TARGET_SYMBOL = 'X'
SUPPLY_SYMBOL = 'F'
BLOCKS = {'R', 'W', 'T'}

# --- 신규 추가: 보급 획득 여부를 기억하는 상태 변수 ---
has_collected_supply = False

def find_positions(grid, start_mark, goal_mark):
    """출발지와 목적지 위치를 찾는 함수"""
    rows, cols = len(grid), len(grid[0])
    start = goal = None
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == start_mark: start = (r, c)
            elif grid[r][c] == goal_mark: goal = (r, c)
            if start and goal: return start, goal
    return start, goal

def get_attack_plan(grid, start, target):
    """목표(target)를 향한 최단 경로 이동 및 공격 계획을 수립"""
    rows, cols = len(grid), len(grid[0])
    q = deque([(start, [])]); visited = {start}
    while q:
        (r, c), current_actions = q.popleft()
        for d, (dr, dc) in enumerate(DIRS):
            is_blocked = False
            for k in range(1, 4):
                nr, nc = r + dr * k, c + dc * k
                if not (0 <= nr < rows and 0 <= nc < cols): break
                if (nr, nc) == target: return current_actions + [FIRE_CMDS[d]]
                if grid[nr][nc] in BLOCKS: is_blocked = True; break
            if is_blocked: continue
        for d, (dr, dc) in enumerate(DIRS):
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and (nr, nc) not in visited and grid[nr][nc] not in BLOCKS:
                visited.add((nr, nc))
                q.append(((nr, nc), current_actions + [MOVE_CMDS[d]]))
    return []

def is_near_supply(pos):
    """내 탱크(pos) 주변에 보급로(F)가 있는지 확인"""
    if not pos: return False
    r, c = pos
    for dr, dc in DIRS:
        nr, nc = r + dr, c + dc
        if 0 <= nr < len(map_data) and 0 <= nc < len(map_data[0]) and map_data[nr][nc] == SUPPLY_SYMBOL:
            return True
    return False

def solve_caesar_with_fixed_key(cipher_text):
    """고정 키(17)로 카이사르 암호를 해독"""
    DECRYPTION_KEY = 17
    plain_text = "".join([chr(((ord(char) - ord('A') - DECRYPTION_KEY) % 26) + ord('A')) for char in cipher_text if 'A' <= char <= 'Z'])
    return f"G {plain_text}"

# 최초 데이터 파싱
parse_data(game_data)

# 최초 행동 계획 수립
start_pos, target_pos = find_positions(map_data, START_SYMBOL, TARGET_SYMBOL)
actions = []
if start_pos and target_pos:
    actions = get_attack_plan(map_data, start_pos, target_pos)

###################################
# 알고리즘 함수/메서드 부분 구현 끝
###################################

# 반복문: 메인 프로그램 <-> 클라이언트(이 코드) 간 순차로 데이터 송수신(동기 처리)
while game_data is not None:
    ##############################
    # 알고리즘 메인 부분 구현 시작
    ##############################
    
    start_pos, target_pos = find_positions(map_data, START_SYMBOL, TARGET_SYMBOL)

    # --- 로직 수정 ---
    # 1. 최우선 순위: 메가 포탄을 아직 얻지 않았고, 보급로 옆이며, 해독할 암호가 있는가?
    if not has_collected_supply and start_pos and is_near_supply(start_pos) and codes:
        output = solve_caesar_with_fixed_key(codes[0])
        # 보급을 시도했으므로, 다음부터는 시도하지 않도록 상태 변경
        has_collected_supply = True
    else:
        # 2. 기본 전략: 포탑 돌격
        if not actions:
            if start_pos and target_pos:
                actions = get_attack_plan(map_data, start_pos, target_pos)
        
        output = actions.pop(0) if actions else 'S'

    # 메인 프로그램에 명령 전송
    game_data = submit(output)
    
    # 수신 후 파싱
    if game_data:
        parse_data(game_data)
    else:
        break

    ##############################
    # 알고리즘 메인 구현 끝
    ##############################

# 반복문을 빠져나왔을 때 메인 프로그램과의 연결을 완전히 해제하기 위해 close() 호출
close()