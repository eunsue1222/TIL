import sys
import socket
from collections import deque

HOST = '127.0.0.1'
PORT = 8747
ARGS = sys.argv[1] if len(sys.argv) > 1 else ''
sock = socket.socket()

def init(nickname):
    sock.connect((HOST, PORT))
    return submit(f'INIT {nickname}')

def submit(cmd):
    sock.send((ARGS + cmd + ' ').encode('utf-8'))
    return receive()

def receive():
    data = sock.recv(2048).decode()
    if data and data[0].isdigit() and int(data[0]) > 0:
        return data
    return None

def close():
    try:
        sock.close()
    except:
        pass

map_data = [[]]
my_allies = {}
enemies = {}
codes = []

def parse_data(game_data):
    rows = game_data.split('\n'); i = 0
    parts = rows[i].split(' '); i+=1
    H = int(parts[0]); W = int(parts[1])
    NA = int(parts[2]); NE = int(parts[3]); NC = int(parts[4])

    map_data.clear(); map_data.extend([['']*W for _ in range(H)])
    for r in range(H):
        cols = rows[i+r].split(' ')
        for c in range(len(cols)):
            map_data[r][c] = cols[c]
    i+=H

    my_allies.clear()
    for _ in range(NA):
        line = rows[i].split(' '); i+=1
        my_allies[line[0]] = line[1:]
    enemies.clear()
    for _ in range(NE):
        line = rows[i].split(' '); i+=1
        enemies[line[0]] = line[1:]
    codes.clear()
    for _ in range(NC):
        codes.append(rows[i]); i+=1

def print_data(game_data):
    print("\n=== Turn Data ===\n", game_data)

# ===== constants =====
DIRS = [(0,1),(1,0),(0,-1),(-1,0)]
MOVE_CMDS = {0:"R A",1:"D A",2:"L A",3:"U A"}
FIRE_CMDS = {0:"R F",1:"D F",2:"L F",3:"U F"}
ROTATE = {0:"R",1:"D",2:"L",3:"U"}

BLOCK = {"R","W","F"}   # impassable
PASS  = {"G","S"}       # walkable
DEST  = {"T"}           # destructible tree

def inb(r,c): return 0<=r<len(map_data) and 0<=c<len(map_data[0])
def my_pos():
    for r in range(len(map_data)):
        for c in range(len(map_data[0])):
            if map_data[r][c]=='M': return (r,c)
def our_turret():
    for r in range(len(map_data)):
        for c in range(len(map_data[0])):
            if map_data[r][c]=='H': return (r,c)
def nearest_enemy_tank():
    me = my_pos()
    best=None; bestd=1e9
    for r in range(len(map_data)):
        for c in range(len(map_data[0])):
            if map_data[r][c].startswith('E'):
                d=abs(me[0]-r)+abs(me[1]-c)
                if d<bestd: best=(r,c); bestd=d
    return best

def los_blocked(tok): return tok in {'R','F','T'}
def los_clear_and_dir(fr,to,maxr=3):
    fr_r,fr_c=fr; tr,tc=to
    if fr_r==tr:
        d=0 if tc>fr_c else 2; step=1 if d==0 else -1
        if 1<=abs(tc-fr_c)<=maxr:
            for c in range(fr_c+step,tc,step):
                if los_blocked(map_data[fr_r][c]): return (False,None)
            return (True,d)
    if fr_c==tc:
        d=1 if tr>fr_r else 3; step=1 if d==1 else -1
        if 1<=abs(tr-fr_r)<=maxr:
            for r in range(fr_r+step,tr,step):
                if los_blocked(map_data[r][fr_c]): return (False,None)
            return (True,d)
    return (False,None)

# BFS shortest path (enemy predicting path to our turret)
def bfs_shortest(start, goal):
    Q=deque([(start,[])])
    vis={start}
    while Q:
        (r,c),path=Q.popleft()
        if (r,c)==goal: return path
        for d,(dr,dc) in enumerate(DIRS):
            nr,nc=r+dr,c+dc
            if not inb(nr,nc) or (nr,nc) in vis: continue
            tok=map_data[nr][nc]
            if tok in BLOCK or tok=='T': continue
            if tok in {'M','H','X'} or tok.startswith('E'): continue
            vis.add((nr,nc))
            Q.append(((nr,nc),path+[(nr,nc)]))
    return []

# BFS from me to goal (with T shooting)
def bfs_to_goal(start, goal):
    Q=deque([(start,[])])
    vis={start}
    while Q:
        (r,c),acts=Q.popleft()
        if (r,c)==goal: return acts
        for d,(dr,dc) in enumerate(DIRS):
            nr,nc=r+dr,c+dc
            if not inb(nr,nc) or (nr,nc) in vis: continue
            tok=map_data[nr][nc]
            if tok in BLOCK: continue
            if tok in PASS:
                vis.add((nr,nc)); Q.append(((nr,nc),acts+[MOVE_CMDS[d]]))
            elif tok=='T':
                vis.add((nr,nc))
                seq=[ROTATE[d], FIRE_CMDS[d], MOVE_CMDS[d]]
                Q.append(((nr,nc),acts+seq))
    return []

def decide_shot_enemy(enemy):
    if not enemy: return None
    me=my_pos()
    ok,dir4=los_clear_and_dir(me,enemy,3)
    if not ok: return None
    # ensure facing
    myfacing=my_allies['M'][1]
    desired=ROTATE[dir4]
    if myfacing!=desired: return desired
    return FIRE_CMDS[dir4]

def emergency_move():
    me=my_pos()
    for d,(dr,dc) in enumerate(DIRS):
        nr,nc=me[0]+dr,me[1]+dc
        if inb(nr,nc) and map_data[nr][nc] in PASS:
            return MOVE_CMDS[d]
    return 'S'

# -------- main --------
NICKNAME = '대전4_권혁준A'
game_data = init(NICKNAME)
parse_data(game_data)

plan=[]; last_enemy=None; predicted=[]

while game_data:
    parse_data(game_data)
    enemy=nearest_enemy_tank()
    shot=decide_shot_enemy(enemy)
    if shot:
        output=shot
        plan=[]
    else:
        need_recalc=False
        if enemy!=last_enemy: need_recalc=True
        if not plan: need_recalc=True
        # 핵심 추가: 적이 예측 경로에서 벗어나면 즉시 재계산
        if enemy and predicted and enemy not in predicted:
            need_recalc=True

        if need_recalc and enemy:
            predicted=bfs_shortest(enemy, our_turret())
            if predicted:
                me=my_pos()
                goal=min(predicted,key=lambda p:abs(p[0]-me[0])+abs(p[1]-me[1]))
            else:
                goal=enemy
            plan=bfs_to_goal(my_pos(),goal)
            last_enemy=enemy

        output=plan.pop(0) if plan else emergency_move()

    game_data=submit(output)

close()
