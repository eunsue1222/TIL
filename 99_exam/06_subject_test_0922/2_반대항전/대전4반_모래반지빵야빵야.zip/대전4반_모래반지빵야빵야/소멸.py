import sys
import socket
from collections import deque
import math

##############################
# 메인 프로그램 통신 변수 정의
##############################
HOST = '127.0.0.1'
PORT = 8747
ARGS = sys.argv[1] if len(sys.argv) > 1 else ''
sock = socket.socket()


##############################
# 메인 프로그램 통신 함수 정의
##############################

# 메인 프로그램 연결 및 초기화
def init(nickname):
    try:
        print(f'[STATUS] Trying to connect to {HOST}:{PORT}...')
        sock.connect((HOST, PORT))
        print('[STATUS] Connected')
        init_command = f'INIT {nickname}'

        return submit(init_command)

    except Exception as e:
        print('[ERROR] Failed to connect. Please check if the main program is waiting for connection.')
        print(e)


# 메인 프로그램으로 데이터(명령어) 전송
def submit(string_to_send):
    try:
        send_data = ARGS + string_to_send + ' '
        sock.send(send_data.encode('utf-8'))

        return receive()

    except Exception as e:
        print('[ERROR] Failed to send data. Please check if connection to the main program is valid.')

    return None


# 메인 프로그램으로부터 데이터 수신
def receive():
    try:
        game_data = (sock.recv(1024)).decode()

        if game_data and game_data[0].isdigit() and int(game_data[0]) > 0:
            return game_data

        print('[STATUS] No receive data from the main program.')
        close()

    except Exception as e:
        print('[ERROR] Failed to receive data. Please check if connection to the main program is valid.')


# 연결 해제
def close():
    try:
        if sock is not None:
            sock.close()
        print('[STATUS] Connection closed')

    except Exception as e:
        print('[ERROR] Network connection has been corrupted.')


##############################
# 입력 데이터 변수 정의
##############################
map_data = [[]]  # 맵 정보. 예) map_data[0][1] - [0, 1]의 지형/지물
my_allies = {}  # 아군 정보. 예) my_allies['M'] - 플레이어 본인의 정보
enemies = {}  # 적군 정보. 예) enemies['X'] - 적 포탑의 정보
codes = []  # 주어진 암호문. 예) codes[0] - 첫 번째 암호문


##############################
# 입력 데이터 파싱
##############################

# 입력 데이터를 파싱하여 각각의 리스트/딕셔너리에 저장
def parse_data(game_data):
    # 입력 데이터를 행으로 나누기
    game_data_rows = game_data.split('\n')
    row_index = 0

    # 첫 번째 행 데이터 읽기
    header = game_data_rows[row_index].split(' ')
    map_height = int(header[0]) if len(header) >= 1 else 0  # 맵의 세로 크기
    map_width = int(header[1]) if len(header) >= 2 else 0  # 맵의 가로 크기
    num_of_allies = int(header[2]) if len(header) >= 3 else 0  # 아군의 수
    num_of_enemies = int(header[3]) if len(header) >= 4 else 0  # 적군의 수
    num_of_codes = int(header[4]) if len(header) >= 5 else 0  # 암호문의 수
    row_index += 1

    # 기존의 맵 정보를 초기화하고 다시 읽어오기
    map_data.clear()
    map_data.extend([['' for c in range(map_width)] for r in range(map_height)])
    for i in range(0, map_height):
        col = game_data_rows[row_index + i].split(' ')
        for j in range(0, len(col)):
            map_data[i][j] = col[j]
    row_index += map_height

    # 기존의 아군 정보를 초기화하고 다시 읽어오기
    my_allies.clear()
    for i in range(row_index, row_index + num_of_allies):
        ally = game_data_rows[i].split(' ')
        ally_name = ally.pop(0) if len(ally) >= 1 else '-'
        my_allies[ally_name] = ally
    row_index += num_of_allies

    # 기존의 적군 정보를 초기화하고 다시 읽어오기
    enemies.clear()
    for i in range(row_index, row_index + num_of_enemies):
        enemy = game_data_rows[i].split(' ')
        enemy_name = enemy.pop(0) if len(enemy) >= 1 else '-'
        enemies[enemy_name] = enemy
    row_index += num_of_enemies

    # 기존의 암호문 정보를 초기화하고 다시 읽어오기
    codes.clear()
    for i in range(row_index, row_index + num_of_codes):
        codes.append(game_data_rows[i])


# 파싱한 데이터를 화면에 출력
def print_data():
    print(f'\n----------입력 데이터----------\n{game_data}\n----------------------------')

    print(f'\n[맵 정보] ({len(map_data)} x {len(map_data[0])})')
    for i in range(len(map_data)):
        for j in range(len(map_data[i])):
            print(f'{map_data[i][j]} ', end='')
        print()

    print(f'\n[아군 정보] (아군 수: {len(my_allies)})')
    for k, v in my_allies.items():
        if k == 'M':
            print(f'M (내 탱크) - 체력: {v[0]}, 방향: {v[1]}, 보유한 일반 포탄: {v[2]}개, 보유한 메가 포탄: {v[3]}개')
        elif k == 'H':
            print(f'H (아군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (아군 탱크) - 체력: {v[0]}')

    print(f'\n[적군 정보] (적군 수: {len(enemies)})')
    for k, v in enemies.items():
        if k == 'X':
            print(f'X (적군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (적군 탱크) - 체력: {v[0]}')

    print(f'\n[암호문 정보] (암호문 수: {len(codes)})')
    for i in range(len(codes)):
        print(codes[i])


##############################
# 닉네임 설정 및 최초 연결
##############################
NICKNAME = '소멸'
game_data = init(NICKNAME)

###################################
# 알고리즘 함수/메서드 부분 구현 시작
###################################

# 경로 탐색 변수 정의
DIRS = [(0, 1), (1, 0), (0, -1), (-1, 0)]  # R, D, L, U
MOVE_CMDS = {0: "R A", 1: "D A", 2: "L A", 3: "U A"}
FIRE_CMDS = {0: "R F", 1: "D F", 2: "L F", 3: "U F"}
START_SYMBOL = 'M'
WALL_SYMBOL = 'R'
WATER_SYMBOL = 'W'
TREE_SYMBOL = 'T'


# **[신규] 내 탱크의 위치를 찾는 함수**
def find_my_position(grid, my_mark):
    for r, row in enumerate(grid):
        for c, tile in enumerate(row):
            if tile == my_mark:
                return (r, c)
    return None


# **[신규] 맵에 있는 모든 적의 위치를 찾는 함수**
def find_all_enemy_positions(grid, enemy_dict):
    enemy_positions = []
    enemy_keys = set(enemy_dict.keys())
    for r, row in enumerate(grid):
        for c, tile in enumerate(row):
            if tile in enemy_keys:
                enemy_positions.append((r, c))
    return enemy_positions


# **[핵심 수정] 현재 능력(메가 포탄 유무)을 고려하여 최단 거리 맵을 생성하는 함수**
def create_distance_map(grid, start_pos, can_break_trees):
    rows, cols = len(grid), len(grid[0])
    distance_map = [[-1 for _ in range(cols)] for _ in range(rows)]

    if not start_pos:
        return distance_map

    sr, sc = start_pos
    # 시작 위치가 맵을 벗어나거나 벽이면 경로 탐색 불가
    if not (0 <= sr < rows and 0 <= sc < cols) or grid[sr][sc] in [WALL_SYMBOL, WATER_SYMBOL]:
        return distance_map

    distance_map[sr][sc] = 0
    queue = deque([(start_pos, 0)])

    while queue:
        (r, c), dist = queue.popleft()

        for dr, dc in DIRS:
            nr, nc = r + dr, c + dc

            if 0 <= nr < rows and 0 <= nc < cols and distance_map[nr][nc] == -1:
                tile_type = grid[nr][nc]
                # 이동 불가 조건: 돌(R) 또는 물(W)
                if tile_type in [WALL_SYMBOL, WATER_SYMBOL]:
                    continue
                # 이동 불가 조건: 나무(T)인데 메가 포탄이 없는 경우
                if tile_type == TREE_SYMBOL and not can_break_trees:
                    continue

                # 위 조건들을 통과하면 이동 가능한 경로로 판단
                distance_map[nr][nc] = dist + 1
                queue.append(((nr, nc), dist + 1))
    return distance_map


# **[수정] 동적인 목표물에 대응하도록 수정한 행동 결정 함수**
def get_next_action(path_map, start, target):
    if not start or not target:
        return 'A'

    rows, cols = len(map_data), len(map_data[0])
    r, c = start

    # 1. 최우선 순위: 직접 사격 (3칸 이내)
    for d, (dr, dc) in enumerate(DIRS):
        for i in range(1, 4):
            nr, nc = r + i * dr, c + i * dc
            if not (0 <= nr < rows and 0 <= nc < cols): break
            if (nr, nc) == target:
                if int(my_allies['M'][2]) > 0:  # 일반 포탄 확인
                    print(f"[ACTION] Target {map_data[nr][nc]} at {target} in range. Firing!")
                    return FIRE_CMDS[d]
                break
            if map_data[nr][nc] == WALL_SYMBOL: break

    # 2. 이동: path_map(목표->시작 경로)을 보고 최단 거리가 짧아지는 방향 탐색
    min_dist = math.inf
    best_dir = -1
    for d, (dr, dc) in enumerate(DIRS):
        nr, nc = r + dr, c + dc
        if 0 <= nr < rows and 0 <= nc < cols and path_map[nr][nc] != -1:
            if path_map[nr][nc] < min_dist:
                min_dist = path_map[nr][nc]
                best_dir = d

    # 3. 행동 결정
    if best_dir != -1:
        nr, nc = r + DIRS[best_dir][0], c + DIRS[best_dir][1]
        next_tile = map_data[nr][nc]

        # 다음 타일이 길('G')이거나 목표 지점이면 이동
        if next_tile == 'G' or (nr, nc) == target:
            print(f"[ACTION] Moving towards target at {target}. Direction: {best_dir}")
            return MOVE_CMDS[best_dir]

        # 다음 타일이 나무('T')이면 메가 포탄으로 파괴
        elif next_tile == TREE_SYMBOL:
            if int(my_allies['M'][3]) > 0:  # 메가 포탄 확인
                print(f"[ACTION] Breaking tree with Mega Bomb. Direction: {best_dir}")
                return FIRE_CMDS[best_dir] + " M"

    print("[ACTION] No optimal move found. Waiting.")
    return 'A'


###################################
# 알고리즘 함수/메서드 부분 구현 끝
###################################

# 최초 데이터 파싱
parse_data(game_data)

# 반복문: 메인 프로그램 <-> 클라이언트(이 코드) 간 순차로 데이터 송수신(동기 처리)
while game_data is not None:
    ##############################
    # 알고리즘 메인 부분 구현 시작
    ##############################
    print_data()

    # **[핵심 로직] 가장 가까운 적을 찾아 목표로 설정**
    start = find_my_position(map_data, START_SYMBOL)
    all_enemies = find_all_enemy_positions(map_data, enemies)

    target = None
    output = 'A'  # 기본값은 대기

    if start and all_enemies:
        # 1. 메가 포탄 보유 여부 확인
        has_mega_bomb = int(my_allies['M'][3]) > 0

        # 2. 내 탱크 위치로부터의 최단 거리 맵 생성 (메가 포탄 여부 반영)
        my_distance_map = create_distance_map(map_data, start, has_mega_bomb)

        # 3. 모든 적까지의 거리를 확인하여 도달 가능한 가장 가까운 적을 찾음
        min_dist_to_enemy = math.inf
        closest_enemy = None
        for enemy_pos in all_enemies:
            dist = my_distance_map[enemy_pos[0]][enemy_pos[1]]
            if dist != -1 and dist < min_dist_to_enemy:
                min_dist_to_enemy = dist
                closest_enemy = enemy_pos

        target = closest_enemy
        if target:
            print(
                f"[STATUS] Current target: {map_data[target[0]][target[1]]} at {target} (Distance: {min_dist_to_enemy})")

            # 4. 선택된 목표 지점으로부터의 내비게이션용 최단 거리 맵 생성 (메가 포탄 여부 반영)
            target_path_map = create_distance_map(map_data, target, has_mega_bomb)

            # 5. 거리 맵을 기반으로 다음 행동 결정
            output = get_next_action(target_path_map, start, target)
        else:
            print("[STATUS] No reachable enemies found. Waiting.")

    else:
        print("[STATUS] My tank or enemies not found. Waiting.")

    print(f"\n>>>>>> SUBMITTING COMMAND: {output} <<<<<<\n")
    game_data = submit(output)

    if game_data:
        parse_data(game_data)
    ##############################
    # 알고리즘 메인 구현 끝
    ##############################

# 반복문을 빠져나왔을 때 메인 프로그램과의 연결을 완전히 해제하기 위해 close() 호출
close()
