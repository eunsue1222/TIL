import sys
import socket
from collections import deque
import time

##############################
# Main Program Communication Variables
##############################
HOST = '127.0.0.1'
PORT = 8747
ARGS = sys.argv[1] if len(sys.argv) > 1 else ''
sock = socket.socket()

##############################
# Main Program Communication Functions
##############################

def init(nickname):
    """Connects to the main program and initializes."""
    try:
        print(f'[STATUS] Trying to connect to {HOST}:{PORT}...')
        sock.connect((HOST, PORT))
        print('[STATUS] Connected')
        init_command = f'INIT {nickname}'
        return submit(init_command)
    except Exception as e:
        print('[ERROR] Failed to connect. Please check if the main program is waiting for connection.')
        print(e)

def submit(string_to_send):
    """Sends data (commands) to the main program."""
    try:
        send_data = ARGS + string_to_send + ' '
        sock.send(send_data.encode('utf-8'))
        return receive()
    except Exception as e:
        print('[ERROR] Failed to send data. Please check if connection to the main program is valid.')
    return None

def receive():
    """Receives data from the main program."""
    try:
        game_data = (sock.recv(1024)).decode()
        if game_data and game_data[0].isdigit() and int(game_data[0]) > 0:
            return game_data
        print('[STATUS] No receive data from the main program.')
        close()
    except Exception as e:
        print('[ERROR] Failed to receive data. Please check if connection to the main program is valid.')

def close():
    """Closes the connection."""
    try:
        if sock is not None:
            sock.close()
        print('[STATUS] Connection closed')
    except Exception as e:
        print('[ERROR] Network connection has been corrupted.')

##############################
# Input Data Variables
##############################
map_data = [[]]
my_allies = {}
enemies = {}
codes = []

##############################
# Input Data Parsing
##############################
def parse_data(game_data):
    """Parses the input game data string into variables."""
    game_data_rows = game_data.split('\n')
    row_index = 0
    header = game_data_rows[row_index].split(' ')
    map_height = int(header[0]) if len(header) >= 1 else 0
    map_width = int(header[1]) if len(header) >= 2 else 0
    num_of_allies = int(header[2]) if len(header) >= 3 else 0
    num_of_enemies = int(header[3]) if len(header) >= 4 else 0
    num_of_codes = int(header[4]) if len(header) >= 5 else 0
    row_index += 1
    map_data.clear()
    map_data.extend([['' for _ in range(map_width)] for _ in range(map_height)])
    for i in range(map_height):
        col = game_data_rows[row_index + i].split(' ')
        for j in range(len(col)):
            map_data[i][j] = col[j]
    row_index += map_height
    my_allies.clear()
    for i in range(row_index, row_index + num_of_allies):
        ally = game_data_rows[i].split(' ')
        ally_name = ally.pop(0) if ally else '-'
        my_allies[ally_name] = ally
    row_index += num_of_allies
    enemies.clear()
    for i in range(row_index, row_index + num_of_enemies):
        enemy = game_data_rows[i].split(' ')
        enemy_name = enemy.pop(0) if enemy else '-'
        enemies[enemy_name] = enemy
    row_index += num_of_enemies
    codes.clear()
    for i in range(row_index, row_index + num_of_codes):
        codes.append(game_data_rows[i])

def print_data():
    """Prints the parsed data to the console for debugging."""
    print(f'\n----------Input Data----------\n{game_data}\n----------------------------')
    print(f'\n[Map Info] ({len(map_data)} x {len(map_data[0])})')
    for row in map_data:
        print(' '.join(row))
    print(f'\n[Ally Info] (Count: {len(my_allies)})')
    for k, v in my_allies.items():
        if k == 'M':
            print(f'M (My Tank) - HP: {v[0]}, Dir: {v[1]}, Shells: {v[2]}, Mega: {v[3]}')
        elif k == 'H':
            print(f'H (Ally Base) - HP: {v[0]}')
        else:
            print(f'{k} (Ally Tank) - HP: {v[0]}')
    print(f'\n[Enemy Info] (Count: {len(enemies)})')
    for k, v in enemies.items():
        if k == 'X':
            print(f'X (Enemy Base) - HP: {v[0]}')
        else:
            print(f'{k} (Enemy Tank) - HP: {v[0]}')
    print(f'\n[Cipher Info] (Count: {len(codes)})')
    for code in codes:
        print(code)

##############################
# Nickname Setting & Initial Connection
##############################
NICKNAME = '대전4_최준형'
game_data = init(NICKNAME)

###################################
# ALGORITHM IMPLEMENTATION START
###################################

# --- Constants and State Variables ---
DIRS = [(0, 1), (1, 0), (0, -1), (-1, 0)]  # R, D, L, U
MOVE_CMDS = ["R A", "D A", "L A", "U A"]
FIRE_CMDS = ["R F", "D F", "L F", "U F"]
FIRE_MEGA_CMDS = ["R F M", "D F M", "L F M", "U F M"]

# Map Symbols
MY_TANK_SYMBOL = 'M'
ENEMY_BASE_SYMBOL = 'X'
ENEMY_TANK_SYMBOLS = ['E1', 'E2', 'E3']
OBSTACLE_SYMBOLS = ['R', 'W', 'T', 'F'] # Rocks, Water, Trees, Supply (cannot move onto)
SUPPLY_SYMBOL = 'F'

# Pre-calculated Caesar cipher shift key based on the manual's example
# SRKKCVJJRWP -> BATTLESSAFY
# Shift = (ord('S') - ord('B')) % 26 = 17
CAESAR_SHIFT_KEY = 17

# AI State
actions = []

# --- Core AI Functions ---

def find_entity_positions(grid, entity_symbol):
    """Finds all positions of a given entity or list of entities on the grid."""
    positions = []
    rows, cols = len(grid), len(grid[0])
    for r in range(rows):
        for c in range(cols):
            if isinstance(entity_symbol, list):
                if grid[r][c] in entity_symbol:
                    positions.append((r, c))
            else:
                if grid[r][c] == entity_symbol:
                    positions.append((r, c))
    return positions

def pathfinding_bfs(grid, start, goal):
    """Finds the shortest path to a target, avoiding obstacles."""
    rows, cols = len(grid), len(grid[0])
    queue = deque([(start, [])])
    visited = {start}

    while queue:
        (r, c), path = queue.popleft()

        if (r, c) == goal:
            return path

        for i, (dr, dc) in enumerate(DIRS):
            nr, nc = r + dr, c + dc

            if 0 <= nr < rows and 0 <= nc < cols and \
               grid[nr][nc] not in OBSTACLE_SYMBOLS and \
               (nr, nc) not in visited:
                visited.add((nr, nc))
                new_path = path + [MOVE_CMDS[i]]
                queue.append(((nr, nc), new_path))
    return []

def find_path_to_adjacent(grid, start, goal):
    """Finds the shortest path to a square adjacent to the goal (e.g., a supply station)."""
    rows, cols = len(grid), len(grid[0])
    goal_r, goal_c = goal
    
    adjacent_targets = []
    for dr, dc in DIRS:
        nr, nc = goal_r + dr, goal_c + dc
        if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] not in OBSTACLE_SYMBOLS:
            adjacent_targets.append((nr, nc))

    if not adjacent_targets:
        return []

    shortest_path = []
    for target in adjacent_targets:
        path = pathfinding_bfs(grid, start, target)
        if path:
            if not shortest_path or len(path) < len(shortest_path):
                shortest_path = path
    
    return shortest_path

def find_target_in_range(grid, start):
    """Finds an attackable enemy within 3-tile range and returns the appropriate fire command."""
    rows, cols = len(grid), len(grid[0])
    r, c = start
    all_enemies = ENEMY_TANK_SYMBOLS + [ENEMY_BASE_SYMBOL]

    for i, (dr, dc) in enumerate(DIRS):
        for dist in range(1, 4):
            nr, nc = r + dr * dist, c + dc * dist
            
            if not (0 <= nr < rows and 0 <= nc < cols):
                break
            
            entity = grid[nr][nc]
            if entity in all_enemies:
                if entity == ENEMY_BASE_SYMBOL and int(my_allies['M'][3]) > 0:
                    return FIRE_MEGA_CMDS[i]
                elif int(my_allies['M'][2]) > 0:
                    return FIRE_CMDS[i]
                elif int(my_allies['M'][3]) > 0:
                    return FIRE_MEGA_CMDS[i]
            
            if entity == 'R': # Rocks block shots
                break
    return None

def decrypt_cipher(ciphertext):
    """Decrypts the Caesar cipher using the pre-calculated shift key."""
    decrypted_message = ""
    for char in ciphertext:
        if 'A' <= char <= 'Z':
            decrypted_char_code = (ord(char) - ord('A') - CAESAR_SHIFT_KEY + 26) % 26
            decrypted_message += chr(decrypted_char_code + ord('A'))
        else:
            decrypted_message += char
    return f"G {decrypted_message}"

###################################
# ALGORITHM IMPLEMENTATION END
###################################

# Main Loop: Synchronous data exchange between the main program and this client
while game_data is not None:
    ##############################
    # ALGORITHM MAIN LOGIC START
    ##############################
    
    # 1. Update State
    parse_data(game_data)
    print_data()
    my_pos = find_entity_positions(map_data, MY_TANK_SYMBOL)[0]

    # 2. Decision Making Logic
    if not actions:
        # Priority 1: Immediate Attack (Self-defense and seizing opportunities)
        fire_command = find_target_in_range(map_data, my_pos)
        if fire_command:
            actions.append(fire_command)
        
        # Strategy: Get 2 mega shells, then attack the base.
        # Check if the primary mission (getting 2 mega shells) is complete.
        elif int(my_allies['M'][3]) >= 2:
            # Mission complete: Attack the enemy base.
            print("[STRATEGY] Mega shells secured. Advancing on enemy base.")
            enemy_base_pos = find_entity_positions(map_data, ENEMY_BASE_SYMBOL)
            if enemy_base_pos:
                path_to_base = pathfinding_bfs(map_data, my_pos, enemy_base_pos[0])
                if path_to_base:
                    actions.extend(path_to_base)
        
        # Mission incomplete: Continue to gather mega shells.
        else:
            # Priority 2: Decrypt Cipher if adjacent to a supply station.
            if codes:
                print("[STRATEGY] Adjacent to supply. Decrypting for mega shells.")
                decryption_command = decrypt_cipher(codes[0])
                actions.append(decryption_command)
            
            # Priority 3: Move to the nearest supply station.
            else:
                supply_positions = find_entity_positions(map_data, SUPPLY_SYMBOL)
                if supply_positions:
                    print("[STRATEGY] Moving to nearest supply station.")
                    closest_supply = min(supply_positions, key=lambda pos: abs(pos[0] - my_pos[0]) + abs(pos[1] - my_pos[1]))
                    path_to_supply = find_path_to_adjacent(map_data, my_pos, closest_supply)
                    if path_to_supply:
                        actions.extend(path_to_supply)
                # Fallback: If no supply stations, attack the base anyway.
                else:
                    print("[STRATEGY] No supply stations found. Attacking base directly.")
                    enemy_base_pos = find_entity_positions(map_data, ENEMY_BASE_SYMBOL)
                    if enemy_base_pos:
                        path_to_base = pathfinding_bfs(map_data, my_pos, enemy_base_pos[0])
                        if path_to_base:
                            actions.extend(path_to_base)

    # 3. Execute Action
    output = actions.pop(0) if actions else 'S' # If no actions, Standby
    print(f"\n>>> Executing Command: {output}")
    
    game_data = submit(output)
    time.sleep(0.05) # A short delay for stability

    ##############################
    # ALGORITHM MAIN LOGIC END
    ##############################

close()

