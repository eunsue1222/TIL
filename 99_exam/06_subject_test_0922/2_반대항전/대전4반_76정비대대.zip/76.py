import sys
import socket
from collections import deque

##############################
# 메인 프로그램 통신 변수 정의
##############################
HOST = '127.0.0.1'
PORT = 8747
ARGS = sys.argv[1] if len(sys.argv) > 1 else ''
sock = socket.socket()


##############################
# 메인 프로그램 통신 함수 정의
##############################

# 메인 프로그램 연결 및 초기화
def init(nickname):
    try:
        print(f'[STATUS] Trying to connect to {HOST}:{PORT}...')
        sock.connect((HOST, PORT))
        print('[STATUS] Connected')
        init_command = f'INIT {nickname}'

        return submit(init_command)

    except Exception as e:
        print('[ERROR] Failed to connect. Please check if the main program is waiting for connection.')
        print(e)


# 메인 프로그램으로 데이터(명령어) 전송
def submit(string_to_send):
    try:
        send_data = ARGS + string_to_send + ' '
        sock.send(send_data.encode('utf-8'))

        return receive()

    except Exception as e:
        print('[ERROR] Failed to send data. Please check if connection to the main program is valid.')

    return None


# 메인 프로그램으로부터 데이터 수신
def receive():
    try:
        game_data = (sock.recv(1024)).decode()

        if game_data and game_data[0].isdigit() and int(game_data[0]) > 0:
            return game_data

        print('[STATUS] No receive data from the main program.')
        close()

    except Exception as e:
        print('[ERROR] Failed to receive data. Please check if connection to the main program is valid.')


# 연결 해제
def close():
    try:
        if sock is not None:
            sock.close()
        print('[STATUS] Connection closed')

    except Exception as e:
        print('[ERROR] Network connection has been corrupted.')


##############################
# 입력 데이터 변수 정의
##############################
map_data = [[]]  # 맵 정보. 예) map_data[0][1] - [0, 1]의 지형/지물
my_allies = {}  # 아군 정보. 예) my_allies['M'] - 플레이어 본인의 정보
enemies = {}  # 적군 정보. 예) enemies['X'] - 적 포탑의 정보
codes = []  # 주어진 암호문. 예) codes[0] - 첫 번째 암호문


##############################
# 입력 데이터 파싱
##############################

# 입력 데이터를 파싱하여 각각의 리스트/딕셔너리에 저장
def parse_data(game_data):
    # 입력 데이터를 행으로 나누기
    game_data_rows = game_data.split('\n')
    row_index = 0

    # 첫 번째 행 데이터 읽기
    header = game_data_rows[row_index].split(' ')
    map_height = int(header[0]) if len(header) >= 1 else 0  # 맵의 세로 크기
    map_width = int(header[1]) if len(header) >= 2 else 0  # 맵의 가로 크기
    num_of_allies = int(header[2]) if len(header) >= 3 else 0  # 아군의 수
    num_of_enemies = int(header[3]) if len(header) >= 4 else 0  # 적군의 수
    num_of_codes = int(header[4]) if len(header) >= 5 else 0  # 암호문의 수
    row_index += 1

    # 기존의 맵 정보를 초기화하고 다시 읽어오기
    map_data.clear()
    map_data.extend([['' for c in range(map_width)] for r in range(map_height)])
    for i in range(0, map_height):
        col = game_data_rows[row_index + i].split(' ')
        for j in range(0, len(col)):
            map_data[i][j] = col[j]
    row_index += map_height

    # 기존의 아군 정보를 초기화하고 다시 읽어오기
    my_allies.clear()
    for i in range(row_index, row_index + num_of_allies):
        ally = game_data_rows[i].split(' ')
        ally_name = ally.pop(0) if len(ally) >= 1 else '-'
        my_allies[ally_name] = ally
    row_index += num_of_allies

    # 기존의 적군 정보를 초기화하고 다시 읽어오기
    enemies.clear()
    for i in range(row_index, row_index + num_of_enemies):
        enemy = game_data_rows[i].split(' ')
        enemy_name = enemy.pop(0) if len(enemy) >= 1 else '-'
        enemies[enemy_name] = enemy
    row_index += num_of_enemies

    # 기존의 암호문 정보를 초기화하고 다시 읽어오기
    codes.clear()
    for i in range(row_index, row_index + num_of_codes):
        codes.append(game_data_rows[i])


# 파싱한 데이터를 화면에 출력
def print_data():
    print(f'\n----------입력 데이터----------\n{game_data}\n----------------------------')

    print(f'\n[맵 정보] ({len(map_data)} x {len(map_data[0])})')
    for i in range(len(map_data)):
        for j in range(len(map_data[i])):
            print(f'{map_data[i][j]} ', end='')
        print()

    print(f'\n[아군 정보] (아군 수: {len(my_allies)})')
    for k, v in my_allies.items():
        if k == 'M':
            print(f'M (내 탱크) - 체력: {v[0]}, 방향: {v[1]}, 보유한 일반 포탄: {v[2]}개, 보유한 메가 포탄: {v[3]}개')
        elif k == 'H':
            print(f'H (아군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (아군 탱크) - 체력: {v[0]}')

    print(f'\n[적군 정보] (적군 수: {len(enemies)})')
    for k, v in enemies.items():
        if k == 'X':
            print(f'X (적군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (적군 탱크) - 체력: {v[0]}')

    print(f'\n[암호문 정보] (암호문 수: {len(codes)})')
    for i in range(len(codes)):
        print(codes[i])


##############################
# 닉네임 설정 및 최초 연결
##############################
NICKNAME = '소위_안치원'
game_data = init(NICKNAME)

###################################
# 알고리즘 함수/메서드 부분 구현 시작
###################################

from collections import deque

# 방향/명령 정의
DIRS = [(0, 1), (1, 0), (0, -1), (-1, 0)]  # R, D, L, U
MOVE_CMDS = {0: "R A", 1: "D A", 2: "L A", 3: "U A"}
FIRE_CMDS = {0: "R F", 1: "D F", 2: "L F", 3: "U F"}
MEGA_CMDS = {0: "R M", 1: "D M", 2: "L M", 3: "U M"}
START_SYMBOL = 'M'
MY_TURRET_SYMBOL = 'H'
WALL_SYMBOL = 'R'
TREE_SYMBOL = 'T'
WATER_SYMBOL = 'W'
HOME_BASE_RADIUS = 4  # 포탑 중심으로부터의 반경 (8x8 영역)


# 유틸: 맵 범위 체크
def in_bounds(r, c):
    return 0 <= r < len(map_data) and 0 <= c < len(map_data[0])


# 특정 심볼의 위치 찾기
def find_pos(mark):
    for r in range(len(map_data)):
        for c in range(len(map_data[0])):
            if map_data[r][c] == mark:
                return (r, c)
    return None


# 직선 시야 확인 (장애물 W/R/T 없으면 True)
def has_line_of_sight(src, dst):
    if not src or not dst: return False
    (r1, c1), (r2, c2) = src, dst
    if r1 == r2:
        step = 1 if c2 > c1 else -1
        for c in range(c1 + step, c2, step):
            if map_data[r1][c] in (WATER_SYMBOL, WALL_SYMBOL, TREE_SYMBOL): return False
        return True
    if c1 == c2:
        step = 1 if r2 > r1 else -1
        for r in range(r1 + step, r2, step):
            if map_data[r][c1] in (WATER_SYMBOL, WALL_SYMBOL, TREE_SYMBOL): return False
        return True
    return False


# 사거리(3) 내 직선 공격 가능 여부 검사
def in_attack_range(src, dst, rng=3):
    if not src or not dst: return False
    (r1, c1), (r2, c2) = src, dst
    dist = abs(r1 - r2) + abs(c1 - c2)
    if dist > rng: return False
    if r1 == r2 or c1 == c2:
        return has_line_of_sight(src, dst)
    return False


# 내 포탄 수 확인
def get_my_ammo():
    m = my_allies.get('M')
    if not m: return 0, 0
    try:
        return int(m[2]), int(m[3])
    except:
        return 0, 0


# 방향 인덱스 계산 (src -> dst)
def direction_index(src, dst):
    (r1, c1), (r2, c2) = src, dst
    if r1 == r2: return 0 if c2 > c1 else 2
    if c1 == c2: return 1 if r2 > r1 else 3
    return None


# 홈 베이스(8x8) 영역 확인
def is_in_home_base(pos, turret_pos):
    if not pos or not turret_pos: return False
    r, c = pos
    tr, tc = turret_pos
    # 포탑 좌표로부터 상하좌우 4칸까지를 홈 베이스로 정의
    return (abs(r - tr) <= HOME_BASE_RADIUS) and (abs(c - tc) <= HOME_BASE_RADIUS)


# BFS 경로 찾기 (나무는 사격 후 이동)
def bfs_path(start, target):
    if not start or not target: return []
    q = deque([(start, [])])
    visited = {start}
    while q:
        (r, c), actions = q.popleft()
        if (r, c) == target: return actions
        for d, (dr, dc) in enumerate(DIRS):
            nr, nc = r + dr, c + dc
            if not in_bounds(nr, nc) or (nr, nc) in visited: continue
            tile = map_data[nr][nc]
            # 아군 포탑(H) 포함, 지나갈 수 없는 타일 지정
            if tile in (WATER_SYMBOL, WALL_SYMBOL, 'F', MY_TURRET_SYMBOL): continue

            new_actions = actions + [MOVE_CMDS[d]]
            # 나무는 사격 후 이동하는 2단계 행동으로 경로에 추가
            if tile == TREE_SYMBOL:
                # 일반 포탄이 있을 때만 나무 제거 시도
                if get_my_ammo()[0] > 0:
                    new_actions = actions + [FIRE_CMDS[d], MOVE_CMDS[d]]
                else:  # 포탄 없으면 나무는 벽과 같음
                    continue

            visited.add((nr, nc))
            q.append(((nr, nc), new_actions))
    return []


# 메인 행동 결정 로직 (수비 및 요격 전략)
def decide_next_action(current_actions):
    my_pos = find_pos(START_SYMBOL)
    turret_pos = find_pos(MY_TURRET_SYMBOL)

    if not my_pos or not turret_pos:
        return "R A", []  # 비상시 기본 이동

    # 1. [요격 모드] 홈 베이스 내 침입한 적 탐색
    intruder_pos = None
    min_dist = float('inf')
    for enemy_name in enemies:
        if enemy_name != 'X':  # 적 포탑 제외
            enemy_pos = find_pos(enemy_name)
            if enemy_pos and is_in_home_base(enemy_pos, turret_pos):
                dist = abs(my_pos[0] - enemy_pos[0]) + abs(my_pos[1] - enemy_pos[1])
                if dist < min_dist:
                    min_dist = dist
                    intruder_pos = enemy_pos

    # 1-1. 침입자(intruder)가 있으면, 공격 또는 이동 경로 생성
    if intruder_pos:
        # 사거리 내에 있으면 즉시 공격
        if in_attack_range(my_pos, intruder_pos):
            dir_idx = direction_index(my_pos, intruder_pos)
            if dir_idx is not None:
                normal_ammo, mega_ammo = get_my_ammo()
                # 일반 포탄 우선 사용
                if normal_ammo > 0:
                    return FIRE_CMDS[dir_idx], []
                elif mega_ammo > 0:
                    return MEGA_CMDS[dir_idx], []

        # 사거리 밖에 있으면 침입자를 향한 새로운 경로 계산
        new_actions = bfs_path(my_pos, intruder_pos)
        if new_actions:
            # 새로운 목표가 생겼으므로 기존 action은 버리고 새 action을 실행
            return new_actions.pop(0), new_actions

    # 2. [순찰 모드] 침입자가 없을 경우
    # 2-1. 기존에 수행하던 행동이 있다면 마저 수행 (예: 포탑 복귀 중)
    if current_actions:
        return current_actions.pop(0), current_actions

    # 2-2. 내가 홈 베이스를 벗어났다면 포탑으로 복귀하는 경로 생성
    if not is_in_home_base(my_pos, turret_pos):
        actions_to_return = bfs_path(my_pos, turret_pos)
        if actions_to_return:
            return actions_to_return.pop(0), actions_to_return

    # 2-3. 홈 베이스 안에서 할 일이 없다면, 옐로카드 방지를 위해 한 칸만 이동
    for d_idx, (dr, dc) in enumerate(DIRS):
        nr, nc = my_pos[0] + dr, my_pos[1] + dc
        # 이동할 곳이 맵 안이고, 홈베이스 안이며, 장애물이 없는 곳이어야 함
        if in_bounds(nr, nc) and is_in_home_base((nr, nc), turret_pos) \
                and map_data[nr][nc] not in (WATER_SYMBOL, WALL_SYMBOL, MY_TURRET_SYMBOL, TREE_SYMBOL):
            # 한 칸짜리 임시 이동 경로 반환
            return MOVE_CMDS[d_idx], []

    # 3. 모든 조건에 해당하지 않을 경우의 비상 이동
    return "R A", []


# 최초 데이터 파싱
parse_data(game_data)
actions = []

###################################
# 알고리즘 함수/메서드 부분 구현 끝
###################################

while game_data is not None:

    ##############################
    # 알고리즘 메인 부분 구현 시작
    ##############################

    print_data()

    # 수비 및 요격 전략에 따라 다음 행동 결정
    output, actions = decide_next_action(actions)

    # 디버깅: 결정된 행동 출력
    print(f'>>> My Action: {output}')

    game_data = submit(output)

    if game_data:
        parse_data(game_data)

    ##############################
    # 알고리즘 메인 구현 끝
    ##############################

close()