import sys
import socket
from collections import deque

##############################
# 메인 프로그램 통신 변수 정의
##############################
HOST = '127.0.0.1'
PORT = 8747
ARGS = sys.argv[1] if len(sys.argv) > 1 else ''
sock = socket.socket()

##############################
# 메인 프로그램 통신 함수 정의
##############################

# 메인 프로그램 연결 및 초기화
def init(nickname):
    try:
        print(f'[STATUS] Trying to connect to {HOST}:{PORT}...')
        sock.connect((HOST, PORT))
        print('[STATUS] Connected')
        init_command = f'INIT {nickname}'
        return submit(init_command)
    except Exception as e:
        print('[ERROR] Failed to connect. Please check if the main program is waiting for connection.')
        print(e)
        return None

# 메인 프로그램으로 데이터(명령어) 전송
def submit(string_to_send):
    try:
        send_data = ARGS + string_to_send + ' '
        sock.send(send_data.encode('utf-8'))
        return receive()
    except Exception as e:
        print('[ERROR] Failed to send data. Please check if connection to the main program is valid.')
        return None

# 메인 프로그램으로부터 데이터 수신
def receive():
    try:
        game_data = (sock.recv(1024)).decode()
        if game_data and game_data[0].isdigit() and int(game_data[0]) > 0:
            return game_data
        print('[STATUS] No receive data from the main program.')
        close()
        return None
    except Exception as e:
        print('[ERROR] Failed to receive data. Please check if connection to the main program is valid.')
        return None

# 연결 해제
def close():
    try:
        if sock is not None:
            sock.close()
        print('[STATUS] Connection closed')
    except Exception as e:
        print('[ERROR] Network connection has been corrupted.')

##############################
# 입력 데이터 변수 정의
##############################
map_data = [[]]
my_allies = {}
enemies = {}
codes = []

##############################
# 입력 데이터 파싱
##############################

def parse_data(game_data):
    game_data_rows = game_data.split('\n')
    row_index = 0

    header = game_data_rows[row_index].split(' ')
    map_height = int(header[0]) if len(header) >= 1 else 0
    map_width = int(header[1]) if len(header) >= 2 else 0
    num_of_allies = int(header[2]) if len(header) >= 3 else 0
    num_of_enemies = int(header[3]) if len(header) >= 4 else 0
    num_of_codes = int(header[4]) if len(header) >= 5 else 0
    row_index += 1

    map_data.clear()
    map_data.extend([['' for _ in range(map_width)] for _ in range(map_height)])
    for i in range(map_height):
        col = game_data_rows[row_index + i].split(' ')
        for j in range(len(col)):
            map_data[i][j] = col[j]
    row_index += map_height

    my_allies.clear()
    for i in range(row_index, row_index + num_of_allies):
        ally = game_data_rows[i].split(' ')
        ally_name = ally.pop(0)
        my_allies[ally_name] = ally
    row_index += num_of_allies

    enemies.clear()
    for i in range(row_index, row_index + num_of_enemies):
        enemy = game_data_rows[i].split(' ')
        enemy_name = enemy.pop(0)
        enemies[enemy_name] = enemy
    row_index += num_of_enemies

    codes.clear()
    for i in range(row_index, row_index + num_of_codes):
        codes.append(game_data_rows[i])

##############################
# 닉네임 설정 및 최초 연결
##############################
NICKNAME = '대전4_유동영영'
game_data = init(NICKNAME)

###################################
# 알고리즘 함수/메서드 부분 구현 시작
###################################

# 출발지와 목적지의 위치 찾기
def find_positions(grid, start_mark, goal_mark):
    rows, cols = len(grid), len(grid[0])
    start = goal = None
    for row in range(rows):
        for col in range(cols):
            if grid[row][col] == start_mark:
                start = (row, col)
            elif grid[row][col] == goal_mark:
                goal = (row, col)
    return start, goal

# 경로 탐색 변수 정의
DIRS = [(0, 1), (1, 0), (0, -1), (-1, 0)]  # 0:R, 1:D, 2:L, 3:U
MOVE_CMDS = {0: "R A", 1: "D A", 2: "L A", 3: "U A"}
FIRE_CMDS = {0: "R F", 1: "D F", 2: "L F", 3: "U F"}
MEGA_FIRE_CMDS = {0: "R F M", 1: "D F M", 2: "L F M", 3: "U F M"}
START_SYMBOL = 'M'
TARGET_SYMBOL = 'X'
WALL_SYMBOL = ['R', 'W', 'T']  # 벽, 물, 나무는 통과 불가

# 경로 탐색 알고리즘 (BFS)
def bfs(grid, start, target, wall):
    rows, cols = len(grid), len(grid[0])
    queue = deque([(start, [])])
    visited = {start}
    
    (start_r, start_c) = start

    # 1. 원거리 공격 로직 (이동보다 우선)
    # 현재 위치에서 4방향으로 장애물 없는 직선거리에 타겟이 있는지 확인
    for d, (dr, dc) in enumerate(DIRS):
        for i in range(1, 4):  # 사거리 3칸
            nr, nc = start_r + dr * i, start_c + dc * i
            
            if not (0 <= nr < rows and 0 <= nc < cols): break
            if grid[nr][nc] in wall: break # 장애물 발견 시 해당 방향 탐색 중지

            if (nr, nc) == target:
                print(f"타겟({target})을 원거리에서 탐지! 발사합니다.")
                # 메가 포탄이 일반 포탄보다 많으면 메가 포탄 사용
                if int(my_allies['M'][3]) > int(my_allies['M'][2]):
                    return [MEGA_FIRE_CMDS[d]]
                else:
                    return [FIRE_CMDS[d]]

    # 2. 이동 경로 탐색
    while queue:
        (r, c), actions = queue.popleft()

        for d, (dr, dc) in enumerate(DIRS):
            nr, nc = r + dr, c + dc
            
            # 맵 범위 체크, 벽 체크, 방문 여부 체크
            if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] not in wall and (nr, nc) not in visited:
                
                # 타겟에 인접했을 경우, 이동 대신 발사
                if (nr, nc) == target:
                    print(f"타겟({target})에 인접! 발사합니다.")
                    if int(my_allies['M'][3]) > int(my_allies['M'][2]):
                        return actions + [MOVE_CMDS[d], MEGA_FIRE_CMDS[d]] # 이동 후 발사
                    else:
                        return actions + [MOVE_CMDS[d], FIRE_CMDS[d]]
                
                visited.add((nr, nc))
                queue.append(((nr, nc), actions + [MOVE_CMDS[d]]))

    return [] # 경로를 찾지 못한 경우

###################################
# 알고리즘 함수/메서드 부분 구현 끝
###################################

# 최초 데이터 파싱
if game_data:
    parse_data(game_data)

# 반복문: 메인 프로그램 <-> 클라이언트(이 코드) 간 순차로 데이터 송수신
while game_data is not None:
    ##############################
    # 알고리즘 메인 부분 구현 시작
    ##############################

    # 현재 상태에서 출발지와 목적지 확인
    start, target = find_positions(map_data, START_SYMBOL, TARGET_SYMBOL)

    # 기본 명령어는 대기('A')
    output = 'A'
    
    # 출발지와 목적지가 모두 존재할 경우에만 경로 탐색
    if start and target:
        # 매 턴마다 현재 맵 상태를 기준으로 최적 행동 계산
        actions = bfs(map_data, start, target, WALL_SYMBOL)
        
        # 계산된 행동이 있으면 첫 번째 행동을 명령어로 지정
        if actions:
            output = actions.pop(0)

    # 메인 프로그램으로 명령 전송 및 다음 데이터 수신
    game_data = submit(output)

    # 수신된 데이터가 있으면 파싱
    if game_data:
        parse_data(game_data)
        
    ##############################
    # 알고리즘 메인 구현 끝
    ##############################

# 연결 해제
close()