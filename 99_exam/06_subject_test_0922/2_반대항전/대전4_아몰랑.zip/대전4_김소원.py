import sys
import socket
from collections import deque

##############################
# 메인 프로그램 통신 변수 정의
##############################
HOST = '127.0.0.1'
PORT = 8747
ARGS = sys.argv[1] if len(sys.argv) > 1 else ''
sock = socket.socket()

##############################
# 메인 프로그램 통신 함수 정의
##############################
def init(nickname):
    try:
        print(f'[STATUS] Trying to connect to {HOST}:{PORT}...')
        sock.connect((HOST, PORT))
        print('[STATUS] Connected')
        init_command = f'INIT {nickname}'
        return submit(init_command)
    except Exception as e:
        print('[ERROR] Failed to connect. Please check if the main program is waiting for connection.')
        print(e)

def submit(string_to_send):
    try:
        send_data = ARGS + string_to_send + ' '
        sock.send(send_data.encode('utf-8'))
        return receive()
    except Exception as e:
        print('[ERROR] Failed to send data. Please check if connection to the main program is valid.')
    return None

def receive():
    try:
        game_data = (sock.recv(1024)).decode()
        if game_data and game_data[0].isdigit() and int(game_data[0]) > 0:
            return game_data
        print('[STATUS] No receive data from the main program.')
        close()
    except Exception as e:
        print('[ERROR] Failed to receive data. Please check if connection to the main program is valid.')

def close():
    try:
        if sock is not None:
            sock.close()
        print('[STATUS] Connection closed')
    except Exception as e:
        print('[ERROR] Network connection has been corrupted.')

##############################
# 입력 데이터 변수 정의
##############################
map_data = [[]]
my_allies = {}
enemies = {}
codes = []

##############################
# 입력 데이터 파싱 및 출력
##############################
def parse_data(game_data):
    game_data_rows = game_data.split('\n')
    row_index = 0

    header = game_data_rows[row_index].split(' ')
    map_height = int(header[0]) if len(header) >= 1 else 0
    map_width  = int(header[1]) if len(header) >= 2 else 0
    num_of_allies  = int(header[2]) if len(header) >= 3 else 0
    num_of_enemies = int(header[3]) if len(header) >= 4 else 0
    num_of_codes   = int(header[4]) if len(header) >= 5 else 0
    row_index += 1

    map_data.clear()
    map_data.extend([['' for _ in range(map_width)] for _ in range(map_height)])
    for i in range(map_height):
        col = game_data_rows[row_index + i].split(' ')
        for j in range(len(col)):
            map_data[i][j] = col[j]
    row_index += map_height

    my_allies.clear()
    for i in range(row_index, row_index + num_of_allies):
        ally = game_data_rows[i].split(' ')
        ally_name = ally.pop(0) if len(ally) >= 1 else '-'
        my_allies[ally_name] = ally
    row_index += num_of_allies

    enemies.clear()
    for i in range(row_index, row_index + num_of_enemies):
        enemy = game_data_rows[i].split(' ')
        enemy_name = enemy.pop(0) if len(enemy) >= 1 else '-'
        enemies[enemy_name] = enemy
    row_index += num_of_enemies

    codes.clear()
    for i in range(row_index, row_index + num_of_codes):
        codes.append(game_data_rows[i])

def print_data():
    print(f'\n----------입력 데이터----------\n{game_data}\n----------------------------')
    print(f'\n[맵 정보] ({len(map_data)} x {len(map_data[0])})')
    for i in range(len(map_data)):
        for j in range(len(map_data[i])):
            print(f'{map_data[i][j]} ', end='')
        print()

    print(f'\n[아군 정보] (아군 수: {len(my_allies)})')
    for k, v in my_allies.items():
        if k == 'M':
            print(f'M (내 탱크) - 체력: {v[0]}, 방향: {v[1]}, 보유한 일반 포탄: {v[2]}개, 보유한 메가 포탄: {v[3]}개')
        elif k == 'H':
            print(f'H (아군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (아군 탱크) - 체력: {v[0]}')

    print(f'\n[적군 정보] (적군 수: {len(enemies)})')
    for k, v in enemies.items():
        print(f'{k} - {v}')

    print(f'\n[암호문 정보] (암호문 수: {len(codes)})')
    for i in range(len(codes)):
        print(codes[i])

##############################
# 닉네임 설정 및 최초 연결
##############################
NICKNAME = '대전4_김소원'
game_data = init(NICKNAME)

###################################
# 알고리즘 상수/도우미
###################################
START_SYMBOL = 'M'
WALL_SYMBOL  = 'R'
WATER_SYMBOL = 'W'
TREE_SYMBOL  = 'T'
SAND_SYMBOL  = 'S'

# 보급소는 피함
SUPPLY_SYMBOLS = {'B', 'b'}
FIRE_RANGE = 3

# 이동 불가(절대 못 지나감): 돌, 물, 보급소, 아군(동적 추가)
BLOCK_MOVE_BASE  = {WALL_SYMBOL, WATER_SYMBOL} | SUPPLY_SYMBOLS
# 사격 시 시야 차단: 돌, 물, 나무
BLOCK_SIGHT = {WALL_SYMBOL, WATER_SYMBOL, TREE_SYMBOL}

def manhattan(a, b):
    return abs(a[0]-b[0]) + abs(a[1]-b[1])

def find_my_start(grid):
    for r in range(len(grid)):
        for c in range(len(grid[0])):
            if grid[r][c] == START_SYMBOL:
                return (r, c)
    return None

# 맵에서 '적 탱크' 위치만 모두 찾기 (포탑 X가 있더라도 무시)
def find_enemy_tank_positions_only(grid, enemies_dict):
    rows, cols = len(grid), len(grid[0])
    pos = []
    enemy_keys = set(enemies_dict.keys())
    if 'X' in enemy_keys:
        enemy_keys.remove('X')
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] in enemy_keys:
                pos.append((grid[r][c], (r, c)))
    return pos

# 적 탱크 중 가장 가까운(맨해튼) 하나 선택
def pick_nearest_enemy(start, enemy_positions):
    if not enemy_positions:
        return None
    sr, sc = start
    best = None
    bestd = float('inf')
    for sym, (er, ec) in enemy_positions:
        d = abs(er - sr) + abs(ec - sc)
        if d < bestd:
            bestd = d
            best = (sym, (er, ec))
    return best

# 상대 위치 기준으로 DIRS 우선순위(전방 성향) 결정
def pick_dirs_by_relative(start, target):
    sr, sc = start
    tr, tc = target
    # 우상(내가 타겟의 오른쪽-상단) → 아래 우선
    if sr <= tr and sc >= tc:
        return [(1,0), (0,-1), (0,1), (-1,0)]   # D, L, R, U
    # 좌하(내가 타겟의 왼쪽-하단) → 위 우선
    if sr >= tr and sc <= tc:
        return [(-1,0), (0,1), (0,-1), (1,0)]   # U, R, L, D
    # 기본: R, D, L, U
    return [(0,1), (1,0), (0,-1), (-1,0)]

def build_cmds_from_dirs(dirs):
    base = {
        (0, 1): ("R A", "R F", "R FM"),
        (1, 0): ("D A", "D F", "D FM"),
        (0,-1): ("L A", "L F", "L FM"),
        (-1,0): ("U A", "U F", "U FM"),
    }
    move, fire, firem = {}, {}, {}
    for idx, d in enumerate(dirs):
        m, f, fm = base[d]
        move[idx], fire[idx], firem[idx] = m, f, fm
    return move, fire, firem

# 직선 사거리 3, 중간 BLOCK_SIGHT 없으면 사격 가능(메가 우선)
def can_fire_at_target(grid, r, c, target, dirs, fire_cmds, firem_cmds, a_left, m_left):
    rows, cols = len(grid), len(grid[0])
    if a_left <= 0 and m_left <= 0:
        return None
    for d, (dr, dc) in enumerate(dirs):
        nr, nc = r, c
        for _ in range(FIRE_RANGE):
            nr += dr; nc += dc
            if not (0 <= nr < rows and 0 <= nc < cols):
                break
            if grid[nr][nc] in BLOCK_SIGHT:
                break
            if (nr, nc) == target:
                return firem_cmds[d] if m_left > 0 else fire_cmds[d]
    return None

# 맵에서 현재 보이는 모든 '적 유닛(탱크 포함)' 좌표(심볼,좌표) 반환
def find_enemy_positions(grid, enemies_dict):
    rows, cols = len(grid), len(grid[0])
    en_positions = []
    enemy_keys = set(enemies_dict.keys())
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] in enemy_keys:
                en_positions.append((grid[r][c], (r, c)))
    return en_positions

# 무작정 적 탱크로 돌진: BFS (행동수 최소)
# 전방(=dirs[0])이 돌(R)이면 즉시 다른 방향(우→좌→후)로 우선순위 변경
def bfs_to_attack_enemy(grid, start, enemy_pos, dirs, move_cmds, fire_cmds, firem_cmds, a_init, m_init):
    rows, cols = len(grid), len(grid[0])
    visited = {}  # (r,c,a,m) -> cost
    q = deque([(start, [], a_init, m_init)])

    # 이동 금지 타일: 돌,물,보급소 + 아군
    ally_symbols = set(my_allies.keys())
    BLOCK_MOVE = BLOCK_MOVE_BASE.union(ally_symbols)

    # 적 타일로는 들어가지 않음(사거리에서 쏘기 위함)
    enemy_all_positions = [pos for _, pos in find_enemy_positions(grid, enemies)]

    while q:
        (r, c), actions, a_left, m_left = q.popleft()
        cost = len(actions)
        state_key = (r, c, a_left, m_left)
        if visited.get(state_key, float('inf')) <= cost:
            continue
        visited[state_key] = cost

        # 1) 현재 자리에서 사격 가능하면 종료
        shoot_cmd = can_fire_at_target(grid, r, c, enemy_pos, dirs, fire_cmds, firem_cmds, a_left, m_left)
        if shoot_cmd:
            return actions + [shoot_cmd]

        # 2) 전방(=dirs[0])이 돌인지 확인 → 방향 우선순위 조정
        dir_indices = [0,1,2,3]
        fr, fc = r + dirs[0][0], c + dirs[0][1]
        if 0 <= fr < rows and 0 <= fc < cols and grid[fr][fc] == WALL_SYMBOL:
            # 전방이 돌이면: 우(1) → 좌(2) → 후(3)
            dir_indices = [1,2,3]

        # 3) 각 방향으로 확장
        for di in dir_indices:
            dr, dc = dirs[di]
            nr, nc = r + dr, c + dc
            if not (0 <= nr < rows and 0 <= nc < cols):
                continue

            tile = grid[nr][nc]

            # 이동 불가
            if tile in BLOCK_MOVE:
                continue
            # 적 타일로 진입 금지
            if (nr, nc) in enemy_all_positions:
                continue

            na, nm = a_left, m_left
            if tile == TREE_SYMBOL:
                # 나무: 쏘고 → 전진(2 행동). 탄 없으면 못감
                if na > 0:
                    new_actions = actions + [fire_cmds[di], move_cmds[di]]
                    na -= 1
                elif nm > 0:
                    new_actions = actions + [firem_cmds[di], move_cmds[di]]
                    nm -= 1
                else:
                    continue
            else:
                new_actions = actions + [move_cmds[di]]

            new_state = (nr, nc, na, nm)
            new_cost = len(new_actions)
            if visited.get(new_state, float('inf')) <= new_cost:
                continue
            q.append(((nr, nc), new_actions, na, nm))

    return []  # 경로 실패

###################################
# 최초 파싱 & 초기 세팅
###################################
parse_data(game_data)

start = find_my_start(map_data)
if not start:
    print("[ERROR] Start not found in map")
    close(); sys.exit()

# 현재 탄수
try:
    myM = my_allies.get('M', ['0','R','1','0'])
    AMMO = int(myM[2]) if len(myM) >= 3 else 1
    MEGA = int(myM[3]) if len(myM) >= 4 else 0
except:
    AMMO, MEGA = 1, 0

actions = []

###################################
# 메인 루프
###################################
while game_data is not None:
    print_data()

    start = find_my_start(map_data)
    if not start:
        print("[ERROR] Start disappeared")
        close(); sys.exit()

    # 최신 탄수 반영
    try:
        myM = my_allies.get('M', ['0','R','1','0'])
        AMMO = int(myM[2]) if len(myM) >= 3 else AMMO
        MEGA = int(myM[3]) if len(myM) >= 4 else MEGA
    except:
        pass

    # 적 탱크들 스캔 & 가장 가까운 하나 선택
    enemy_positions = find_enemy_tank_positions_only(map_data, enemies)
    chosen = pick_nearest_enemy(start, enemy_positions)

    if chosen:
        _, enemy_pos = chosen
        # 타겟 상대 위치 기반으로 전방 성향 DIRS 세팅
        DIRS = pick_dirs_by_relative(start, enemy_pos)
        MOVE_CMDS, FIRE_CMDS, FIREM_CMDS = build_cmds_from_dirs(DIRS)

        # 돌진 BFS (앞이 돌이면 곧장 우->좌->후로 피해감)
        actions = bfs_to_attack_enemy(
            map_data, start, enemy_pos,
            DIRS, MOVE_CMDS, FIRE_CMDS, FIREM_CMDS,
            AMMO, MEGA
        )
    else:
        actions = []

    output = actions.pop(0) if actions else 'A'
    game_data = submit(output)

    if game_data:
        parse_data(game_data)

close()
