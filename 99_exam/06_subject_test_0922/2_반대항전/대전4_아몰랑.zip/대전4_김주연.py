import sys
import socket
from collections import deque

##############################
# 메인 프로그램 통신 변수 정의
##############################
HOST = '127.0.0.1'
PORT = 8747
ARGS = sys.argv[1] if len(sys.argv) > 1 else ''
sock = socket.socket()

##############################
# 메인 프로그램 통신 함수 정의
##############################
def init(nickname):
    try:
        print(f'[STATUS] Trying to connect to {HOST}:{PORT}...')
        sock.connect((HOST, PORT))
        print('[STATUS] Connected')
        init_command = f'INIT {nickname}'
        return submit(init_command)
    except Exception as e:
        print('[ERROR] Failed to connect. Please check if the main program is waiting for connection.')
        print(e)

def submit(string_to_send):
    try:
        send_data = ARGS + string_to_send + ' '
        sock.send(send_data.encode('utf-8'))
        return receive()
    except Exception as e:
        print('[ERROR] Failed to send data. Please check if connection to the main program is valid.')
    return None

def receive():
    try:
        game_data = (sock.recv(1024)).decode()
        if game_data and game_data[0].isdigit() and int(game_data[0]) > 0:
            return game_data
        print('[STATUS] No receive data from the main program.')
        close()
    except Exception as e:
        print('[ERROR] Failed to receive data. Please check if connection to the main program is valid.')

def close():
    try:
        if sock is not None:
            sock.close()
        print('[STATUS] Connection closed')
    except Exception as e:
        print('[ERROR] Network connection has been corrupted.')

##############################
# 입력 데이터 변수 정의
##############################
map_data = [[]]
my_allies = {}
enemies = {}
codes = []

##############################
# 입력 데이터 파싱 및 출력
##############################
def parse_data(game_data):
    game_data_rows = game_data.split('\n')
    row_index = 0

    header = game_data_rows[row_index].split(' ')
    map_height = int(header[0]) if len(header) >= 1 else 0
    map_width  = int(header[1]) if len(header) >= 2 else 0
    num_of_allies  = int(header[2]) if len(header) >= 3 else 0
    num_of_enemies = int(header[3]) if len(header) >= 4 else 0
    num_of_codes   = int(header[4]) if len(header) >= 5 else 0
    row_index += 1

    map_data.clear()
    map_data.extend([['' for _ in range(map_width)] for _ in range(map_height)])
    for i in range(map_height):
        col = game_data_rows[row_index + i].split(' ')
        for j in range(len(col)):
            map_data[i][j] = col[j]
    row_index += map_height

    my_allies.clear()
    for i in range(row_index, row_index + num_of_allies):
        ally = game_data_rows[i].split(' ')
        ally_name = ally.pop(0) if len(ally) >= 1 else '-'
        my_allies[ally_name] = ally
    row_index += num_of_allies

    enemies.clear()
    for i in range(row_index, row_index + num_of_enemies):
        enemy = game_data_rows[i].split(' ')
        enemy_name = enemy.pop(0) if len(enemy) >= 1 else '-'
        enemies[enemy_name] = enemy
    row_index += num_of_enemies

    codes.clear()
    for i in range(row_index, row_index + num_of_codes):
        codes.append(game_data_rows[i])

def print_data():
    print(f'\n----------입력 데이터----------\n{game_data}\n----------------------------')
    print(f'\n[맵 정보] ({len(map_data)} x {len(map_data[0])})')
    for i in range(len(map_data)):
        for j in range(len(map_data[i])):
            print(f'{map_data[i][j]} ', end='')
        print()

    print(f'\n[아군 정보] (아군 수: {len(my_allies)})')
    for k, v in my_allies.items():
        if k == 'M':
            print(f'M (내 탱크) - 체력: {v[0]}, 방향: {v[1]}, 보유한 일반 포탄: {v[2]}개, 보유한 메가 포탄: {v[3]}개')
        elif k == 'H':
            print(f'H (아군 포탑) - 체력: {v[0]}')
        else:
            print(f'{k} (아군 탱크) - 체력: {v[0]}')

    print(f'\n[적군 정보] (적군 수: {len(enemies)})')
    for k, v in enemies.items():
        print(f'{k} - {v}')

    print(f'\n[암호문 정보] (암호문 수: {len(codes)})')
    for i in range(len(codes)):
        print(codes[i])

##############################
# 닉네임 설정 및 최초 연결
##############################
NICKNAME = '대전4_김주연'
game_data = init(NICKNAME)

###################################
# 알고리즘 상수/도우미
###################################
START_SYMBOL = 'M'
TARGET_SYMBOL = 'X'   # turret symbol
WALL_SYMBOL  = 'R'
WATER_SYMBOL = 'W'
TREE_SYMBOL  = 'T'
SAND_SYMBOL  = 'S'

SUPPLY_SYMBOLS = {'B', 'b'}           # 보급소는 피함
FIRE_RANGE = 3

# 이동 불가(절대 못 지나감): 돌, 물, 보급소, 아군(동적 추가)
BLOCK_MOVE_BASE  = {WALL_SYMBOL, WATER_SYMBOL} | SUPPLY_SYMBOLS
# 사격 시 시야 차단: 돌, 물, 나무
BLOCK_SIGHT = {WALL_SYMBOL, WATER_SYMBOL, TREE_SYMBOL}

# 절대 방향(고정)
DIRS = [(0,1),(1,0),(0,-1),(-1,0)]  # 0:R, 1:D, 2:L, 3:U
MOVE_CMDS = {0:"R A", 1:"D A", 2:"L A", 3:"U A"}
FIRE_CMDS = {0:"R F", 1:"D F", 2:"L F", 3:"U F"}
FIREM_CMDS= {0:"R FM",1:"D FM",2:"L FM",3:"U FM"}

# my_allies['M'][1] 방향 문자를 dir 인덱스로
def dir_char_to_idx(ch):
    return {'R':0,'D':1,'L':2,'U':3}.get(ch, 0)

def find_positions(grid, start_mark, goal_mark):
    rows, cols = len(grid), len(grid[0])
    start = goal = None
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == start_mark:
                start = (r, c)
            elif grid[r][c] == goal_mark:
                goal = (r, c)
    return start, goal

def manhattan(a, b):
    return abs(a[0]-b[0]) + abs(a[1]-b[1])

def find_enemy_positions(grid, enemies_dict):
    rows, cols = len(grid), len(grid[0])
    en_positions = []
    enemy_keys = set(enemies_dict.keys())
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] in enemy_keys:
                en_positions.append((grid[r][c], (r, c)))
    return en_positions

def find_enemy_tank_positions_only(grid, enemies_dict):
    rows, cols = len(grid), len(grid[0])
    pos = []
    enemy_keys = set(enemies_dict.keys())
    if 'X' in enemy_keys:
        enemy_keys.remove('X')
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] in enemy_keys:
                pos.append((grid[r][c], (r, c)))
    return pos

def choose_nearest_target(start, grid, enemies_dict):
    # 탱크 vs 포탑 중 가까운 쪽
    tanks = find_enemy_tank_positions_only(grid, enemies_dict)
    tank_best, tank_best_d = None, float('inf')
    for sym, p in tanks:
        d = manhattan(start, p)
        if d < tank_best_d:
            tank_best, tank_best_d = ('enemy', p), d
    turret_pos = find_positions(grid, START_SYMBOL, TARGET_SYMBOL)[1]
    turret_best, turret_best_d = None, float('inf')
    if turret_pos:
        turret_best, turret_best_d = ('turret', turret_pos), manhattan(start, turret_pos)
    if tank_best and turret_best:
        return tank_best if tank_best_d <= turret_best_d else turret_best
    return tank_best or turret_best

# 직선 사거리 3, 중간 BLOCK_SIGHT 없을 때 사격 가능. 메가 우선.
def can_fire_at_target(grid, r, c, target, a_left, m_left):
    rows, cols = len(grid), len(grid[0])
    if a_left <= 0 and m_left <= 0:
        return None
    for d, (dr, dc) in enumerate(DIRS):
        nr, nc = r, c
        for _ in range(FIRE_RANGE):
            nr += dr; nc += dc
            if not (0 <= nr < rows and 0 <= nc < cols):
                break
            if grid[nr][nc] in BLOCK_SIGHT:
                break
            if (nr, nc) == target:
                return FIREM_CMDS[d] if m_left > 0 else FIRE_CMDS[d]
    return None

# BFS: 상태에 (r,c,dir, 남은 일반/메가)을 포함
# 확장 우선순위: 기본은 [전, 우, 좌, 후], 단 "전방이 돌(R)"이면 [우, 좌, 후]
def bfs_to_attack_target_with_facing(grid, start, start_dir, target_pos, a_init, m_init):
    rows, cols = len(grid), len(grid[0])
    ally_symbols = set(my_allies.keys())
    BLOCK_MOVE = BLOCK_MOVE_BASE.union(ally_symbols)

    visited_cost = {}  # (r,c,dir,a,m) -> min cost
    q = deque([ (start, start_dir, [], a_init, m_init) ])  # ((r,c), dir, actions, a_left, m_left)

    while q:
        (r, c), dir_idx, actions, a_left, m_left = q.popleft()
        state_key = (r, c, dir_idx, a_left, m_left)
        cost = len(actions)
        if visited_cost.get(state_key, float('inf')) <= cost:
            continue
        visited_cost[state_key] = cost

        # 1) 현재 자리에서 사격 가능하면 종료(메가 우선)
        shoot = can_fire_at_target(grid, r, c, target_pos, a_left, m_left)
        if shoot:
            return actions + [shoot]

        # 2) 확장 우선순위 결정
        fwd = dir_idx
        right = (dir_idx + 1) % 4
        left  = (dir_idx + 3) % 4
        back  = (dir_idx + 2) % 4

        # 전방 타일 살펴보고 돌이면 우선순위를 변경
        fr, fc = r + DIRS[fwd][0], c + DIRS[fwd][1]
        fwd_is_rock = False
        if 0 <= fr < rows and 0 <= fc < cols and grid[fr][fc] == WALL_SYMBOL:
            fwd_is_rock = True

        if fwd_is_rock:
            dir_order = [right, left, back]
        else:
            dir_order = [fwd, right, left, back]

        # 3) 각 방향으로 확장
        for nd in dir_order:
            nr, nc = r + DIRS[nd][0], c + DIRS[nd][1]
            if not (0 <= nr < rows and 0 <= nc < cols):
                continue

            tile = grid[nr][nc]

            # 절대 이동 불가: 돌/물/보급소/아군
            if tile in BLOCK_MOVE:
                continue

            # 적 유닛 타일로 "들어가진 않음" (사거리에서 쏘는 전략)
            if (nr, nc) in [pos for _, pos in find_enemy_positions(grid, enemies)]:
                continue

            na, nm = a_left, m_left

            if tile == TREE_SYMBOL:
                # 나무면 사격 후 전진(2 행동). 탄 없으면 못 감.
                if na > 0:
                    new_actions = actions + [FIRE_CMDS[nd], MOVE_CMDS[nd]]
                    na -= 1
                elif nm > 0:
                    new_actions = actions + [FIREM_CMDS[nd], MOVE_CMDS[nd]]
                    nm -= 1
                else:
                    continue
            else:
                # 일반 타일 이동(모래 포함)
                new_actions = actions + [MOVE_CMDS[nd]]

            new_state = ((nr, nc), nd, new_actions, na, nm)
            new_key = (nr, nc, nd, na, nm)
            new_cost = len(new_actions)
            if visited_cost.get(new_key, float('inf')) <= new_cost:
                continue
            q.append(new_state)

    return []  # 도달 실패

###################################
# 최초 파싱 & 초기 세팅
###################################
parse_data(game_data)

# 내 시작 위치와 시작 방향
start = None
for r in range(len(map_data)):
    for c in range(len(map_data[0])):
        if map_data[r][c] == START_SYMBOL:
            start = (r,c); break
    if start: break

if not start:
    print("[ERROR] Start not found in map")
    close(); sys.exit()

# 내 방향(문자) 읽기 -> dir index
try:
    myM = my_allies.get('M', ['0','R','1','0'])  # [hp, dir_char, ammo, mega]
    start_dir = dir_char_to_idx(myM[1]) if len(myM) >= 2 else 0
    AMMO = int(myM[2]) if len(myM) >= 3 else 1
    MEGA = int(myM[3]) if len(myM) >= 4 else 0
except:
    start_dir, AMMO, MEGA = 0, 1, 0

actions = []

###################################
# 메인 루프
###################################
while game_data is not None:
    print_data()

    # 현재 내 위치/방향/탄수 갱신
    start = None
    for r in range(len(map_data)):
        for c in range(len(map_data[0])):
            if map_data[r][c] == START_SYMBOL:
                start = (r,c); break
        if start: break

    if not start:
        print("[ERROR] Start disappeared")
        close(); sys.exit()

    try:
        myM = my_allies.get('M', ['0','R','1','0'])
        start_dir = dir_char_to_idx(myM[1]) if len(myM) >= 2 else start_dir
        AMMO = int(myM[2]) if len(myM) >= 3 else AMMO
        MEGA = int(myM[3]) if len(myM) >= 4 else MEGA
    except:
        pass

    # 타겟 선택: 적 탱크 vs 포탑 중 더 가까운 쪽
    choice = choose_nearest_target(start, map_data, enemies)

    if choice:
        _, target_pos = choice
        actions = bfs_to_attack_target_with_facing(
            map_data, start, start_dir, target_pos, AMMO, MEGA
        )
    else:
        actions = []

    output = actions.pop(0) if actions else 'A'
    game_data = submit(output)

    if game_data:
        parse_data(game_data)

close()
