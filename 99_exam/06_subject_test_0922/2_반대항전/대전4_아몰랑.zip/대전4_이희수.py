import sys
import socket
from collections import deque

##############################
# 통신 설정
##############################
HOST = '127.0.0.1'
PORT = 8747
ARGS = sys.argv[1] if len(sys.argv) > 1 else ''
sock = socket.socket()

def init(nickname):
    try:
        sock.connect((HOST, PORT))
        return submit(f'INIT {nickname}')
    except Exception as e:
        print('[ERROR] Connect fail:', e)
    return None

def submit(string_to_send):
    try:
        send_data = ARGS + string_to_send + ' '
        sock.send(send_data.encode('utf-8'))
        return receive()
    except Exception as e:
        print('[ERROR] Send fail:', e)
    return None

def receive():
    try:
        # 수신 버퍼를 약간 크게 잡음
        game_data = sock.recv(16384).decode()
        if game_data and game_data[0].isdigit():
            return game_data
        close()
    except Exception as e:
        print('[ERROR] Receive fail:', e)
    return None

def close():
    try:
        if sock:
            sock.close()
    except:
        pass

##############################
# 전역 데이터
##############################
map_data = [[]]
my_allies = {}
enemies = {}
codes = []
known_shift = None   # 카이사르 shift 보관
supplies = []        # 보급소 좌표 리스트
code_map = {}        # 보급소 좌표 -> 암호문 매핑

##############################
# 파싱
##############################
def parse_data(game_data):
    global map_data, my_allies, enemies, codes, supplies, code_map
    rows = game_data.split('\n')
    idx = 0
    header = rows[idx].split(' ')
    # 안전하게 파싱
    H = int(header[0]) if len(header) > 0 else 0
    W = int(header[1]) if len(header) > 1 else 0
    M = int(header[2]) if len(header) > 2 else 0
    E = int(header[3]) if len(header) > 3 else 0
    S = int(header[4]) if len(header) > 4 else 0
    idx += 1

    map_data = [['' for _ in range(W)] for _ in range(H)]
    for r in range(H):
        cols = rows[idx + r].split(' ')
        for c in range(len(cols)):
            map_data[r][c] = cols[c]
    idx += H

    my_allies = {}
    for i in range(M):
        parts = rows[idx + i].split(' ')
        if parts:
            my_allies[parts[0]] = parts[1:]
    idx += M

    enemies = {}
    for i in range(E):
        parts = rows[idx + i].split(' ')
        if parts:
            enemies[parts[0]] = parts[1:]
    idx += E

    codes = []
    for i in range(S):
        codes.append(rows[idx + i])
    idx += S

    # 보급소 위치와 암호문 매핑
    supplies = []
    for r in range(H):
        for c in range(W):
            if map_data[r][c] == 'F':
                supplies.append((r, c))
    code_map = {}
    for i, pos in enumerate(supplies):
        if i < len(codes):
            code_map[pos] = codes[i]

    # 전역에 반영
    globals()['map_data'] = map_data
    globals()['my_allies'] = my_allies
    globals()['enemies'] = enemies
    globals()['codes'] = codes
    globals()['supplies'] = supplies
    globals()['code_map'] = code_map

##############################
# 상수 / 명령
##############################
DIRS = [(0,1),(1,0),(0,-1),(-1,0)]  # R, D, L, U
MOVE_CMDS = {0:"R A",1:"D A",2:"L A",3:"U A"}
FIRE_CMDS = {0:"R F",1:"D F",2:"L F",3:"U F"}
MEGA_CMDS = {0:"R F M",1:"D F M",2:"L F M",3:"U F M"}

WALL = 'R'
WATER = 'W'
TREE = 'T'
SAND = 'S'
SUPPLY = 'F'
TURRET = 'X'

##############################
# 유틸 함수
##############################
def get_my_pos():
    for r in range(len(map_data)):
        for c in range(len(map_data[0])):
            if map_data[r][c] == 'M':
                return (r, c)
    return None

def get_turret_pos():
    for r in range(len(map_data)):
        for c in range(len(map_data[0])):
            if map_data[r][c] == TURRET:
                return (r, c)
    return None

def get_enemy_tanks():
    # 'E' 로 시작하는 셀을 적 탱크로 간주
    res = []
    H = len(map_data); W = len(map_data[0]) if H>0 else 0
    for r in range(H):
        for c in range(W):
            cell = map_data[r][c]
            if cell and cell.startswith('E'):
                res.append((r,c,cell))
    return res

##############################
# 카이사르 해독 (명령 문자열 반환만 함)
##############################
def caesar_shift(text, shift):
    res = []
    for ch in text:
        if 'A' <= ch <= 'Z':
            res.append(chr((ord(ch) - ord('A') - shift) % 26 + ord('A')))
        elif 'a' <= ch <= 'z':
            res.append(chr((ord(ch) - ord('a') - shift) % 26 + ord('a')))
        else:
            res.append(ch)
    return ''.join(res)

def try_decode_supply_command(pos):
    """보급소 pos에 대해 보낼 G 명령 하나를 만들어 반환 (전송은 메인 루프에서).
       만약 known_shift이 None이면 첫 시도용 후보를 반환(실제 정답 판정은 서버 응답 후 확인)."""
    global known_shift
    if pos not in code_map:
        return None
    code = code_map[pos]
    if known_shift is None:
        # 아직 shift 모를 때: 시도할 후보 하나만 반환
        # (루프에서 계속 다시 호출되어 다음 번엔 또 다른 후보를 넣도록 할 수도 있음.
        # 간단하게는 매번 0..25 순서로 시도되게 action_queue 관리 가능)
        # 여기서는 0번 shift을 우선 반환 — 메인 루프에서 실패 시 다시 호출하면 다음 후보를 반환하도록 구현할 수 있음.
        for s in range(26):
            candidate = caesar_shift(code, s)
            return f"G {candidate}"
    else:
        candidate = caesar_shift(code, known_shift)
        return f"G {candidate}"

##############################
# BFS (나무는 한 턴에 F + A 묶음, 모래는 피함)
##############################
def bfs_target(start, target):
    H = len(map_data); W = len(map_data[0])
    q = deque([(start, [])])
    visited = {start}
    while q:
        (r, c), path = q.popleft()
        if (r, c) == target:
            return path
        for d, (dr, dc) in enumerate(DIRS):
            nr, nc = r + dr, c + dc
            if not (0 <= nr < H and 0 <= nc < W):
                continue
            if (nr, nc) in visited:
                continue
            cell = map_data[nr][nc]
            # 모래는 피함 (요청 따라 모래 안밟기)
            if cell in (WALL, WATER, SAND):
                continue
            # 나무는 "한 턴에 발사+이동" 묶음으로 큐에 추가
            if cell == TREE:
                new_path = list(path) + [[FIRE_CMDS[d], MOVE_CMDS[d]]]
                q.append(((nr, nc), new_path))
                visited.add((nr, nc))
                continue
            # 그 외는 이동
            new_path = list(path) + [MOVE_CMDS[d]]
            # 만약 (nr,nc)가 목표와 같은 위치라면, 우리가 그 칸에 도달한 이후 추가 처리가 필요.
            q.append(((nr, nc), new_path))
            visited.add((nr, nc))
    return []

##############################
# 포탑 사거리 검사 (직선 1~3칸, 장애물(R,W) 차단)
##############################
def turret_in_fire_range(mypos):
    """만약 포탑(X)가 사거리 안(직선 1~3칸)에 있으면 (True, dir_index) 반환, 아니면 (False, None)."""
    if not mypos:
        return False, None
    r0, c0 = mypos
    H = len(map_data); W = len(map_data[0])
    for d, (dr, dc) in enumerate(DIRS):
        for dist in range(1, 4):
            rr = r0 + dr * dist
            cc = c0 + dc * dist
            if not (0 <= rr < H and 0 <= cc < W):
                break
            # 장애물(벽, 물) 발견 시 사거리 차단
            if map_data[rr][cc] in (WALL, WATER):
                break
            if map_data[rr][cc] == TURRET:
                return True, d
            # 나무는 관통 여부가 규칙에 따라 다를 수 있으나 여기서는 나무는 관통 가능으로 두지 않음.
            # 만약 나무를 관통 가능하게 하려면 위의 if에서 TREE 제외하면 됨.
    return False, None

##############################
# 명령 결정
##############################
def choose_action():
    """우선순위:
       1) 포탑이 사거리 내이면 포탄 발사 (메가 우선)
       2) 보급소 위에 있으면 G 시도(메인 루프에서 처리)
       3) 포탑으로 돌격 경로(나무는 한 턴에 F+A 묶음)
       4) 기본 대기 'S'
    """
    mypos = get_my_pos()
    if not mypos:
        return ["S"]

    # 1) 포탑 사거리 검사
    in_range, d = turret_in_fire_range(mypos)
    if in_range:
        # 메가포 우선
        try:
            mega_cnt = int(my_allies.get('M', [0,0,0,0])[3])
        except:
            mega_cnt = 0
        try:
            norm_cnt = int(my_allies.get('M', [0,0,0,0])[2])
        except:
            norm_cnt = 0

        if mega_cnt > 0:
            return [MEGA_CMDS[d]]
        elif norm_cnt > 0:
            return [FIRE_CMDS[d]]
        else:
            # 발사할 포탄이 없으면 회피(한칸 이동) 시도
            # 간단히 오른쪽 이동 권장(안전한 칸이면)
            nr, nc = mypos[0] + DIRS[d][0], mypos[1] + DIRS[d][1]
            # fallback: choose any adjacent valid cell
            for dd, (dr, dc) in enumerate(DIRS):
                ar, ac = mypos[0] + dr, mypos[1] + dc
                if 0 <= ar < len(map_data) and 0 <= ac < len(map_data[0]):
                    if map_data[ar][ac] not in (WALL, WATER, SAND):
                        return [MOVE_CMDS[dd]]
            return ["S"]

    # 2) 포탑이 사거리 밖이면 포탑까지 돌격
    turret_pos = get_turret_pos()
    if turret_pos:
        path = bfs_target(mypos, turret_pos)
        if path:
            return path

    return ["S"]

##############################
# 메인 실행
##############################
NICKNAME = "대전4_이희수"
game_data = init(NICKNAME)
if not game_data:
    print("no initial data")
    close()
    sys.exit()

# 초기 파싱
parse_data(game_data)

action_queue = deque()
# 보급소 해독 시도 회전 인덱스 (각 보급소마다 다음에 시도할 shift 인덱스 추적 가능)
supply_next_shift = {}  # pos -> next shift to try (0..25)

while game_data is not None:
    mypos = get_my_pos()

    # (A) 보급소 위에 있으면 G 명령 생성하여 action_queue에 넣기 (보급소 위에서만)
    if mypos and mypos in code_map and not action_queue:
        pos = mypos
        code = code_map.get(pos)
        if code:
            # 어떤 shift를 시도할지 결정
            next_shift = supply_next_shift.get(pos, 0)
            candidate = caesar_shift(code, next_shift)
            g_cmd = f"G {candidate}"
            # enqueue G command (실제 전송은 아래에서 submit)
            action_queue.append(g_cmd)
            # 준비: 다음에 실패하면 다음 shift를 시도하게 저장 (루프에서 실패 확인 후 업데이트)
            supply_next_shift[pos] = (next_shift + 1) % 26

    # (B) action_queue 비어있으면 행동 결정(포탑 돌격 / 발사 등)
    if not action_queue:
        actions = choose_action()
        # actions는 리스트(명령열) 또는 ["S"]
        for act in (actions if isinstance(actions, list) else [actions]):
            action_queue.append(act)

    # (C) action_queue에서 하나 꺼내 실행
    if action_queue:
        output = action_queue.popleft()
    else:
        output = "S"

    # 보안: G는 반드시 보급소 위에서만 보내기
    if isinstance(output, str) and output.startswith("G"):
        if not mypos or map_data[mypos[0]][mypos[1]] != SUPPLY:
            # 보급소 위가 아니면 차단
            output = "S"

    # 나무 묶음 처리: output이 리스트(예: ["R F","R A"])이면 같은 턴에 순차 전송
    if isinstance(output, list):
        # output is a list of commands that should be executed immediately in sequence (same turn)
        for cmd in output:
            game_data = submit(cmd)
            if not game_data:
                break
            parse_data(game_data)
        # 한 묶음 실행 후 다음 루프로 (이미 서버로부터 응답을 받아 파싱했으므로 continue)
        continue

    # 일반 명령 전송(한 명령)
    game_data = submit(output)
    if not game_data:
        break
    # 서버 응답 파싱
    parse_data(game_data)

    # G 명령 성공 판정: 만약 직전에 G를 썼고 메가포탄이 증가했다면 known_shift을 세팅
    # (여기서는 supply_next_shift가 이미 증가한 상태이므로, 성공시 정확한 shift를 역산하려면 복잡하나
    # 단순화: 이후에 known_shift 설정 로직을 추가하려면 prev_mega를 저장하고 비교하는 방식 사용 가능.)

# 종료
close()
