import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 데이터 로드
file_path = './data/dementia_train_dataset.csv'
data = pd.read_csv(file_path)

################### 코드 작성 ###################
# 문제 07. 성별(M/F)과 치매 발병 여부(Group)에 따라 뇌 용적 비율(nWBV)의 차이를 Boxplot으로 비교하세요.


###############################################

plt.title("nWBV by Gender and Dementia Group")
plt.xlabel("Gender")
plt.ylabel("nWBV")
plt.show()

################### 코드 작성 ###################
# 문제 08. Group이 ‘Demented’인 사람들의 데이터를 필터링하고, 성별별 치매 발병률을 계산하고, 이를 막대 그래프로 시각화하시오.


###############################################
plt.title('Dementia Incidence Rate by Gender (%)')
plt.xlabel('Gender')
plt.ylabel('Dementia Incidence Rate (%)')
plt.show()

