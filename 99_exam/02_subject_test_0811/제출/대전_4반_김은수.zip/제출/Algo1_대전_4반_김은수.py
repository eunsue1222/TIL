# import sys
# sys.stdin = open('algo1_sample_in.txt')

def dfs(current_item, index, material, time):
    global result

    # 가지 치기
    if material > current_item[0] or time > current_item[1]: # 필요한 재료 수 초과한 경우 or 연성 소요 시간 초과한 경우
        return

    # 종료 조건
    if index == I:
        if material == current_item[0] and time == current_item[1]:
            result.append(current_item[2])
        return

    # 탐색
    # dfs(current_item, index+1, material+1, time+J[index]) # 선택 o
    # dfs(current_item, index+1, material, time) # 선택 x
    for idx in range(I):
        dfs(current_item, idx+1, material+1, time+J[idx])


T = int(input())
for test_case in range(1, T+1):
    N = int(input()) # N: 물품의 종류
    items = [list(map(int, input().split())) for _ in range(N)] # M: 물건 개수, L: 시간, K: 상품의 가치
    I = int(input()) # I: 총 재료의 개수
    J = list(map(int, input().split())) # J: 재료별 소요시간

    result = [] # 가능한 가치

    # 각 아이템을 연성할 수 있는지 확인
    for item in items:
        dfs(item, 0, 0, 0)

    if len(result) > 0:
        answer = max(result) # 최대 가치
    else:
        answer = 0

    print(f'#{test_case} {answer}')