# import sys
# sys.stdin = open('algo2_sample_in.txt')

T = int(input())
for test_case in range(1, T+1):
    N = int(input()) # N: 요소 수
    cost = list(input()) # cost: 비용

    stack = [] # 스택
    total = 0 # 유지보수 비용

    for c in cost:
        if c == '[': # '['인 경우
            stack.append(c)
        elif c == ']': # ']'인 경우
            stack.pop()
        elif c == ',' or c == ' ': # ',' 또는 ' ' 인 경우
            continue
        else: # 숫자인 경우
            total += int(c) * len(stack) # 총 비용 = 유지보수 비용 * depth

    print(f'#{test_case} {total}')