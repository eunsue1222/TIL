class Book:
    pass

# 아래 코드는 수정 할 수 없음
book1 = Book("파이썬 완벽 가이드", "홍길동", 2023, 35000)
book2 = Book.from_string("자료구조의 이해/이순신/2021/28000")

print(book1.get_info())
# [파이썬 완벽 가이드 - 홍길동, 2023년, 35000원]
print(Book.is_expensive(35000))  # True
print(Book.get_book_count())     # 2
