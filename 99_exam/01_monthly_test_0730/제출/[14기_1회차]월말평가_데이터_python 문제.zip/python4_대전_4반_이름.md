| 문제 4 : 이름공간 (배점 15점)

아래 코드의 출력 결과를 예상하고, 인스턴스 변수와 클래스 변수의 탐색 순서와 관련하여 그 이유를 설명하시오.

```python
class MyClass:
    value = 10

obj = MyClass()
obj.value = 20

print(MyClass.value)
print(obj.value)
```