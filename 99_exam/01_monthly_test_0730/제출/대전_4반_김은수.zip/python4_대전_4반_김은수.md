| 문제 4 : 이름공간 (배점 15점)

아래 코드의 출력 결과를 예상하고, 인스턴스 변수와 클래스 변수의 탐색 순서와 관련하여 그 이유를 설명하시오.

```python
class MyClass:
    value = 10

obj = MyClass()
obj.value = 20

print(MyClass.value)
print(obj.value)
```
- 코드의 출력 결과:<br>
  10<br>
20
  
- 이유: 
print(MyClass.value)는 클래스 변수 10을 나타내므로 10이 출력된다.
  print(obj.value)는 위의 코드에서 obj라는 MyClass 인스턴스를 생성하고, 그 인스턴스 변수 value를 20으로 변경하기 때문에 20이 출력된다. 
  인스턴스는 클래스를 참조하지만 인스턴스 변수 고유의 값을 가지기 때문에 인스턴스 값을 변경할 수 있다.