def strip_and_lowercase(text):
    """
    문자열의 앞뒤 공백을 제거하고, 소문자로 변환한 문자열을 반환한다.
    """
    return text.strip().lower() # 문자열 공백 제거 및 소문자 변환


def is_valid_log(text):
    """
    로그 항목이 유효한지 검사한다.
    유효하지 않은 경우는 다음 조건 중 하나라도 해당되는 경우이다.
    - 공백 문자열
    - "error" 또는 "none" 이 포함된 문자열
    - 숫자로만 구성된 문자열
    """
    if (" " in text) or ("error" in text) or ("none" in text) or (text.isnumeric()): # 문자열 유효성 검사
        status = False
    else:
        status = True
    return status # 유효 상태 반환


def clean_log(text):
    """
    '_'가 포함된 경우 이를 ' '로 바꾸고,
    각 단어의 첫 글자를 대문자로 바꾼다. (Title Case)
    """
    new_text = text.split('_') # 문자열 '_'로 분리
    new_text = ' '.join(t.capitalize() for t in new_text) # 각 단어 대문자 변환 및 ' '으로 붙이기
    return new_text


def process_logs(log_list):
    """
    전체 로그 리스트를 받아 유효한 항목만 정제하여 리스트로 반환한다.
    위 함수들을 적절히 활용해야 한다.
    """
    results = []
    for log in log_list: # 데이터 하나씩
        data = strip_and_lowercase(log) # 공백 제거 및 소문자 변환
        if is_valid_log(data): # 유효성 검사
            data = clean_log(data) # 문자열 변경 및 대문자 변환
            if not data == '':
                results.append(data) # 데이터 저장
    return results


# 아래 코드는 수정 할 수 없음
raw_logs = [
    "  user_login  ",
    "ERROR_404",
    "   page_viewed",
    "None",
    "signup_success ",
    "  1234 ",
    "   ",
]

result = process_logs(raw_logs)
print(result)
# ['User login', 'Page viewed', 'Signup success']