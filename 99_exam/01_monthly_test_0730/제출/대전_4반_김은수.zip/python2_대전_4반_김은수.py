class Book:
    book_count = 0 # 도서 수

    def __init__(self, title, author, year, price): # 생성자 메서드
        self.title = title
        self.author = author
        self.year = year
        self.price = price
        Book.book_count += 1 # 생성자가 호출될 때마다 도서 수 증가

    def get_info(self): # 인스턴스 메서드
        return f'[{self.title} - {self.author}, {self.year}년, {self.price}원]' # 도서 문자열 반환

    @staticmethod
    def is_expensive(price): # 정적 메서드
        if price >= 30000:
            return True # 30000원 이상. 비싸다.
        else:
            return False # #30000원 미만. 비싸지 않다.

    @classmethod
    def get_book_count(cls): # 클래스 메서드
        return cls.book_count # 도서 수 반환

    @classmethod
    def from_string(cls, info_str): # 클래스 메서드
        splited_info = info_str.split('/')
        return Book(*splited_info) # 새로운 Book 인스턴스 반환


# 아래 코드는 수정 할 수 없음
book1 = Book("파이썬 완벽 가이드", "홍길동", 2023, 35000)
book2 = Book.from_string("자료구조의 이해/이순신/2021/28000")

print(book1.get_info())
# [파이썬 완벽 가이드 - 홍길동, 2023년, 35000원]
print(Book.is_expensive(35000))  # True
print(Book.get_book_count())     # 2