# import sys
# sys.stdin = open('algo1_sample_in.txt')

def make_set(x):
    return [i for i in range(N+1)]

def find_set(x):
    if x != parent[x]:
        parent[x] = find_set(parent[x])
    return parent[x]

def union(x, y):
    root_x = find_set(x)
    root_y = find_set(y)
    if root_x != root_y:
        parent[root_y] = root_x
    return

def kruskal(arr):
    mst = []
    total_cost = 0
    arr.sort(key=lambda x: x[2])

    for _ in range(len(arr)):
        start, end, cost = arr.pop(0)
        if find_set(start) != find_set(end):
            union(start, end)
            total_cost += cost
            mst.append((start, end, cost))

    return mst, total_cost


T = int(input()) # (1 <= T <= 10)
for test_case in range(1, T+1):
    N, M = map(int, input().split()) # N: 우주정거장 개수 , M: 가능한 연결의 수 (1 <= N, M <= 10^4)
    info = [list(map(int, input().split())) for _ in range(M)] # X, Y (1 <= X, Y <= N, X != Y), cost (1 <= cost <= 10^5)

    parent = make_set(N)
    mst, min_cost = kruskal(info)

    # if len(mst) != N-1:
    if len(set(parent[1:])) != 1:
        result = -1
    else:
        result = min_cost

    print(f'#{test_case} {result}')