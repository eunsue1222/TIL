import sys
sys.stdin = open('algo2_sample_in.txt')

from collections import deque

dx = [-1 ,1, 0, 0]
dy = [0, 0, -1, 1]

def expand(x, y, char):
    queue = deque()
    queue.append((x, y, char))

    while queue:
        pos_x, pos_y, alp = queue.pop()
        for d in range(4):
            nx = pos_x + dx[d]
            ny = pos_y + dy[d]
            if 0 <= nx < M and 0 <= ny < N and grid[nx][ny] == '.':
                new_grid[nx][ny] = char
                queue.append((nx, ny, char))


T = int(input())
for test_case in range(1, T+1):
    N, M = map(int, input().split()) # N: 가로크기, M: 세로크기 ( 5 <= N, M <= 100)
    K = int(input()) # K: 세균 종류 (1 <= K <= 26)
    spread = list(map(int, input().split())) # A: 세균 별 최대 증식 가능 크기
    grid = [list(input().split()) for _ in range(M)]
    new_grid = grid[:]
    alphabet = ['A', 'B', 'C', 'D', 'E', 'F']

    # for i in range(M):
    #     print(grid[i])

    for k in range(K):  # 알파벳
        for i in range(M): # 가로
            for j in range(N): # 세로
                if grid[i][j] == alphabet[k]:
                    expand(i, j, grid[i][j])
                    new_grid = grid[:]


    #
    # for i in range(M):
    #     print(grid[i])