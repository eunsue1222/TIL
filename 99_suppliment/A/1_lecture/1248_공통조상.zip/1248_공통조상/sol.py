import sys
sys.stdin = open('input.txt')


def find_A_acient(node):
    acient_node = set()
    while node != 1:
        node = tree[node][0]
        acient_node.add(node)

    return acient_node

def find_B_acient(node):
    while node != 1:
        node = tree[node][0]
        if node in A_acient:
            return node

def preorder(node):
    global result

    if node:
        result += 1
        preorder(tree[node][1])
        preorder(tree[node][2])


T = int(input())

for tc in range(1, T+1):
    V, E, A, B = map(int, input().split())
    # 트리구성: 부모, 왼쪽자식, 오른쪽 자식
    tree = [[0, 0, 0] for _ in range(V+1)]
    edges = list(map(int, input().split()))
    for idx in range(E):
        parent = edges[idx*2]
        child = edges[idx*2+1]
        tree[child][0] = parent
        if tree[parent][1]:
            tree[parent][2] = child
        else:
            tree[parent][1] = child

    A_acient = find_A_acient(A)
    commonness_acient = find_B_acient(B)
    result = 0
    preorder(commonness_acient)
    print(f'#{tc} {commonness_acient} {result}')