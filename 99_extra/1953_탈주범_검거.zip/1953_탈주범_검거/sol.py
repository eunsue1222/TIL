import sys
sys.stdin = open('input.txt')

# key: 내 현재 위치의 파이프 번호
# value: 내가 이동하려고 하는 방향에 따라서, 그 쪽에 있어야할 파이프번호
# adj_tunnel[내 위치에 있는 파이프 번호][이동하고자 하는 방향]
# adj_tunnel[data[x][y]][k]  >>> 내 현재위치가 1번 파이프일떄, 위로 이동하려고 하면? [1, 2, 5, 6]
adj_tunnel = {
        # 상           하            좌            우
    1: [[1, 2, 5, 6],  [1, 2, 4, 7], [1, 3, 4, 5], [1, 3, 6, 7]],
    2: [[1, 2, 5, 6],  [1, 2, 4, 7], [], []],
    3: [[], [], [1, 3, 4, 5], [1, 3, 6, 7]],
    4: [[1, 2, 5, 6], [], [], [1, 3, 6, 7]],
    5: [[], [1, 2, 4 ,7], [], [1, 3, 6, 7]],
    6: [[], [1, 2, 4, 7], [1, 3, 4, 5], []],
    7: [[1, 2, 5, 6], [], [1, 3, 4, 5], []],
}

# 터널 정보
# 1번 터널인 경우, x, y에 각각 (-1, 0), (1, 0), (0, -1), (0, 1) 을 더할 수 있음.
# 델타 탐색을
# for k in range(4) 가 아니라 ---> for dx, dy in tunnel[data[x][y]]
# tunnel = {
#     # 상하좌우
#     1: [(-1, 0), (1, 0), (0, -1), (0, 1)],
#     2: [(-1, 0), (1, 0)]   # 상하
#     ...
# }


    # 상 하 좌 우
dx = [-1, 1, 0, 0]  # row에 대해서 델타
dy = [0, 0, -1, 1]  # col에 대해서 델타

def search(x, y):   # 시작 좌표 R, C
    global result
    # 너비우선 탐색 할 거니까, queue
    queue = [(x, y)]

    visited[x][y] = 1   # 방문 표시

    while queue:
        x, y = queue.pop(0)
        # print(queue)
        # adj_tunnel[내가 이동하려는 방향][그 위치에 있는 파이프 번호]
        # 이번 후보군 조사 -> 도달 가능한 지역
        result += 1

        # 그 위치에서 4방향 델타 탐색
        for k in range(4):
            nx = x + dx[k]
            ny = y + dy[k]
            # data[x][y] == 1,                data[x-1][y] == ?
            # data[x][y] == 1,                data[x+1][y] == ?
            # data[x][y] == 1,                data[x][y-1] == ?
            # data[x][y] == 1,                data[x][y+1] == ?
            '''
                탐색 가능 대상인지를 조사할 다른 조건을 만들자.
                터널 정보
                1. 상하좌우
                2. 상하
                3. 좌우
                4. 상우
                5. 하우
                6. 하좌
                7. 상좌
                
                내가 1이면, 상하좌우로 갈수있음
                data[x][y] == 1,                data[x-1][y] == 1, 2, 5, 6
                내가 1이고, 내가 위로 이동하려고 할때, 이동가능한 경우는? 아래로 연결한 파이프가 있어야함
                data[x][y] == 1,                data[x+1][y] == 1, 2, 4, 7
                내가 1이고, 내가 아래로 이동하려고 할때, 이동가능한 경우는? 위로 연결한 파이프가 있어야함
            '''
            if 0 <= nx < N and 0 <= ny < M and data[nx][ny] != 0 and visited[nx][ny] == 0:
                # 내 위치 기준 인접 노드인지 판별
                if data[nx][ny] in adj_tunnel[data[x][y]][k]:
                    # 위 조건들 다 통과하면? 다음 후보군이다.
                    # 내 현재 위치 보다 + 1
                    visited[nx][ny] += (visited[x][y] + 1)
                    # 소요 가능 시간을 초과하면... 후보군에 안넣는다!
                    # 그리고 BFS 방식에, 방문한적 있으면 가지도 않을거라서...
                    # 사실상... pop된 후보군 수를 세면... 그게 방문한 총 칸의 개수
                    if visited[nx][ny] <= L:
                        queue.append((nx, ny))



T = int(input())
for tc in range(1, T+1):
    # 세로 크기 N, 가로 크기 M, 세로 위치 R, 가로 위치 C, 시간 L
    N, M, R, C, L = map(int, input().split())
    # 지도 정보 N 줄, 각 줄마다 M 개의 숫자
    # 데이터를 몇줄에 걸쳐서 받아야하지?
    data = [list(map(int, input().split())) for _ in range(N)]
    '''
        문제 키고 팔짱 끼기 ㄴㄴ
        방금전 봤던 로직들 다 손으로 써보기
        1. BFS(R, C)
        2. 델타탐색 (상하좌우)
        
        3. L이 될떄까지 < - BFS 탐색하면서 L이 됐는지 확인할 방법이 필요하네?
        4. 이미 한번 왔던 곳 다시 갈 필요 없네? (visited 체크를 무조건 해야하는거 아님)
        5. 최종적으로, L시간 전까지 몇칸이나 갔는지 세기.
            6. 문제는 어디서 발생하느냐? 이걸 한번에 다할려고함
    '''
    result = 0  # 최종 결괏값
    # 갔던 곳 또 방문 하면 안됨
    visited = [[0] * M for _ in range(N)]
    search(R, C)

    # for i in range(N):
    #     for j in range(M):
    #         if visited[i][j]:
    #             result += 1


    print(f'#{tc} {result}')
